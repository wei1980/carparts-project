--
-- PostgreSQL database dump
--

\restrict 6lOPnsraWNO5BTRoRtyw3FZaQuZMLsisOobRSVCy9sNHDYoyb4Ufky6RUPzLmH3

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: rule_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.rule_type AS ENUM (
    'discount_pct',
    'add_pct',
    'fixed_price',
    'fixed_markup'
);


ALTER TYPE public.rule_type OWNER TO postgres;

--
-- Name: scope_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.scope_type AS ENUM (
    'part',
    'brand',
    'category',
    'global'
);


ALTER TYPE public.scope_type OWNER TO postgres;

--
-- Name: user_role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.user_role AS ENUM (
    'garage',
    'wholesaler',
    'member',
    'retail'
);


ALTER TYPE public.user_role OWNER TO postgres;

--
-- Name: update_timestamp(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_timestamp() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: garage_query_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.garage_query_logs (
    id integer NOT NULL,
    garage_id integer NOT NULL,
    query_type character varying(50) NOT NULL,
    query_count integer DEFAULT 0,
    query_limit integer DEFAULT 100,
    reset_date date NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.garage_query_logs OWNER TO postgres;

--
-- Name: garage_query_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.garage_query_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.garage_query_logs_id_seq OWNER TO postgres;

--
-- Name: garage_query_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.garage_query_logs_id_seq OWNED BY public.garage_query_logs.id;


--
-- Name: garages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.garages (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    tax_id character varying(20),
    line_id character varying(50),
    phone character varying(20),
    contact_person character varying(100),
    address text NOT NULL,
    map_url text,
    latitude numeric(10,8),
    longitude numeric(11,8),
    business_hours jsonb,
    specialized_brands integer[],
    feature_tags text[],
    payment_methods text[],
    technician_count integer,
    parking_slots integer,
    has_towing_service boolean DEFAULT false,
    license_photo_url text,
    environment_photos text[],
    revenue_share numeric(5,2),
    bank_account jsonb,
    user_id integer,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.garages OWNER TO postgres;

--
-- Name: garages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.garages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.garages_id_seq OWNER TO postgres;

--
-- Name: garages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.garages_id_seq OWNED BY public.garages.id;


--
-- Name: generations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.generations (
    id integer NOT NULL,
    model_id integer NOT NULL,
    name character varying(50),
    year_from integer,
    year_to integer,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.generations OWNER TO postgres;

--
-- Name: generations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.generations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.generations_id_seq OWNER TO postgres;

--
-- Name: generations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.generations_id_seq OWNED BY public.generations.id;


--
-- Name: makes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.makes (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    country character varying(100),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.makes OWNER TO postgres;

--
-- Name: makes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.makes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.makes_id_seq OWNER TO postgres;

--
-- Name: makes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.makes_id_seq OWNED BY public.makes.id;


--
-- Name: models; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.models (
    id integer NOT NULL,
    make_id integer NOT NULL,
    name character varying(100) NOT NULL,
    external_code character varying(50),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.models OWNER TO postgres;

--
-- Name: models_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.models_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.models_id_seq OWNER TO postgres;

--
-- Name: models_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.models_id_seq OWNED BY public.models.id;


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_items (
    id integer NOT NULL,
    order_id integer NOT NULL,
    part_id integer NOT NULL,
    quantity integer NOT NULL,
    price_twd numeric(12,2) NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    CONSTRAINT order_items_quantity_check CHECK ((quantity > 0))
);


ALTER TABLE public.order_items OWNER TO postgres;

--
-- Name: order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.order_items_id_seq OWNER TO postgres;

--
-- Name: order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.order_items_id_seq OWNED BY public.order_items.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    id integer NOT NULL,
    garage_id integer NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.orders_id_seq OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.orders_id_seq OWNED BY public.orders.id;


--
-- Name: part_compatibilities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.part_compatibilities (
    id integer NOT NULL,
    part_id integer NOT NULL,
    vehicle_variant_id integer NOT NULL,
    note jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.part_compatibilities OWNER TO postgres;

--
-- Name: part_compatibilities_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.part_compatibilities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.part_compatibilities_id_seq OWNER TO postgres;

--
-- Name: part_compatibilities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.part_compatibilities_id_seq OWNED BY public.part_compatibilities.id;


--
-- Name: parts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parts (
    id integer NOT NULL,
    sku character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    category character varying(100) NOT NULL,
    brand character varying(100),
    price_twd numeric(12,2) NOT NULL,
    cost_twd numeric(12,2),
    currency character varying(3) DEFAULT 'TWD'::character varying,
    weight_kg numeric(8,3),
    vat_included boolean DEFAULT true,
    stock_qty integer DEFAULT 0,
    description text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT parts_cost_twd_check CHECK ((cost_twd >= (0)::numeric)),
    CONSTRAINT parts_price_twd_check CHECK ((price_twd > (0)::numeric)),
    CONSTRAINT parts_stock_qty_check CHECK ((stock_qty >= 0))
);


ALTER TABLE public.parts OWNER TO postgres;

--
-- Name: parts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.parts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.parts_id_seq OWNER TO postgres;

--
-- Name: parts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.parts_id_seq OWNED BY public.parts.id;


--
-- Name: price_rules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.price_rules (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    role public.user_role,
    scope_type public.scope_type NOT NULL,
    scope_value character varying(100),
    rule_type public.rule_type NOT NULL,
    value numeric(10,4) NOT NULL,
    priority integer DEFAULT 10,
    active boolean DEFAULT true,
    valid_from timestamp without time zone,
    valid_to timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.price_rules OWNER TO postgres;

--
-- Name: price_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.price_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.price_rules_id_seq OWNER TO postgres;

--
-- Name: price_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.price_rules_id_seq OWNED BY public.price_rules.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    display_name character varying(100) NOT NULL,
    email character varying(255),
    role public.user_role DEFAULT 'garage'::public.user_role NOT NULL,
    password_hash text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: vehicle_variants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vehicle_variants (
    id integer NOT NULL,
    model_id integer NOT NULL,
    generation_id integer,
    variant_name character varying(100),
    year_from integer NOT NULL,
    year_to integer NOT NULL,
    engine_code character varying(50),
    displacement_cc integer,
    power_ps integer,
    intake_type character varying(50),
    drive_type character varying(20),
    front_suspension character varying(100),
    rear_suspension character varying(100),
    fuel_type character varying(50) NOT NULL,
    special_tech text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.vehicle_variants OWNER TO postgres;

--
-- Name: vehicle_variants_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.vehicle_variants_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.vehicle_variants_id_seq OWNER TO postgres;

--
-- Name: vehicle_variants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.vehicle_variants_id_seq OWNED BY public.vehicle_variants.id;


--
-- Name: garage_query_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.garage_query_logs ALTER COLUMN id SET DEFAULT nextval('public.garage_query_logs_id_seq'::regclass);


--
-- Name: garages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.garages ALTER COLUMN id SET DEFAULT nextval('public.garages_id_seq'::regclass);


--
-- Name: generations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.generations ALTER COLUMN id SET DEFAULT nextval('public.generations_id_seq'::regclass);


--
-- Name: makes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.makes ALTER COLUMN id SET DEFAULT nextval('public.makes_id_seq'::regclass);


--
-- Name: models id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.models ALTER COLUMN id SET DEFAULT nextval('public.models_id_seq'::regclass);


--
-- Name: order_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items ALTER COLUMN id SET DEFAULT nextval('public.order_items_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders ALTER COLUMN id SET DEFAULT nextval('public.orders_id_seq'::regclass);


--
-- Name: part_compatibilities id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.part_compatibilities ALTER COLUMN id SET DEFAULT nextval('public.part_compatibilities_id_seq'::regclass);


--
-- Name: parts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts ALTER COLUMN id SET DEFAULT nextval('public.parts_id_seq'::regclass);


--
-- Name: price_rules id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.price_rules ALTER COLUMN id SET DEFAULT nextval('public.price_rules_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: vehicle_variants id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vehicle_variants ALTER COLUMN id SET DEFAULT nextval('public.vehicle_variants_id_seq'::regclass);


--
-- Data for Name: garage_query_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.garage_query_logs (id, garage_id, query_type, query_count, query_limit, reset_date, created_at) FROM stdin;
\.


--
-- Data for Name: garages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.garages (id, name, tax_id, line_id, phone, contact_person, address, map_url, latitude, longitude, business_hours, specialized_brands, feature_tags, payment_methods, technician_count, parking_slots, has_towing_service, license_photo_url, environment_photos, revenue_share, bank_account, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: generations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.generations (id, model_id, name, year_from, year_to, created_at) FROM stdin;
1	1	E87	2004	2011	2025-09-16 01:08:47.522179
2	2	E90	2005	2012	2025-09-16 01:08:47.533525
3	2	E90	2007	2010	2025-09-16 01:08:47.538619
4	2	F30	2012	2018	2025-09-16 01:08:47.542923
5	2	F30	2015	2019	2025-09-16 01:08:47.545784
6	2	G20	2019	2023	2025-09-16 01:08:47.548571
7	3	E60	2003	2010	2025-09-16 01:08:47.55624
8	3	F10	2010	2016	2025-09-16 01:08:47.559425
9	3	G30	2017	2023	2025-09-16 01:08:47.562495
10	4	F01	2008	2015	2025-09-16 01:08:47.568269
11	4	G11	2015	2022	2025-09-16 01:08:47.572907
12	4	G11	2016	2022	2025-09-16 01:08:47.576106
13	5	F25	2010	2017	2025-09-16 01:08:47.579315
14	5	G01	2017	2023	2025-09-16 01:08:47.582172
15	6	E70	2006	2013	2025-09-16 01:08:47.587001
16	6	F15	2013	2018	2025-09-16 01:08:47.590591
17	6	G05	2018	2023	2025-09-16 01:08:47.594345
18	7	E89	2009	2016	2025-09-16 01:08:47.598073
19	7	G29	2018	2023	2025-09-16 01:08:47.602493
20	8	I01	2013	2022	2025-09-16 01:08:47.606064
21	9	I12	2014	2020	2025-09-16 01:08:47.609195
22	10	I20	2021	2023	2025-09-16 01:08:47.612463
23	11	E90	2007	2013	2025-09-16 01:08:47.616634
24	11	F80	2014	2018	2025-09-16 01:08:47.619673
25	11	G80	2020	2023	2025-09-16 01:08:47.622374
26	12	F10	2011	2016	2025-09-16 01:08:47.62546
27	12	F90	2017	2023	2025-09-16 01:08:47.628588
28	13	F97	2019	2023	2025-09-16 01:08:47.632893
29	14	F85	2013	2018	2025-09-16 01:08:47.636091
30	15	F96	2019	2023	2025-09-16 01:08:47.639039
31	16	F44	2020	2023	2025-09-16 01:08:47.642385
32	17	F32	2014	2020	2025-09-16 01:08:47.64666
33	17	G22	2020	2023	2025-09-16 01:08:47.649957
34	18	G32	2017	2020	2025-09-16 01:08:47.653031
35	19	G15	2018	2023	2025-09-16 01:08:47.65593
36	20	G02	2018	2023	2025-09-16 01:08:47.659216
37	21	G07	2018	2023	2025-09-16 01:08:47.663628
38	22	G26	2021	2023	2025-09-16 01:08:47.666671
39	23	G82	2022	2023	2025-09-16 01:08:47.669599
40	12	F90	2021	2022	2025-09-16 01:08:47.672379
41	24	G09	2023	2023	2025-09-16 01:08:47.675797
42	2	E46	2003	2004	2025-09-16 01:08:47.679864
43	25	W203	2004	2007	2025-09-16 01:08:47.683344
44	25	W204	2008	2014	2025-09-16 01:08:47.686072
45	25	W205	2015	2021	2025-09-16 01:08:47.688719
46	25	W206	2021	2025	2025-09-16 01:08:47.691907
47	26	W211	2004	2009	2025-09-16 01:08:47.696269
48	26	W212	2009	2016	2025-09-16 01:08:47.699097
49	26	W213	2016	2023	2025-09-16 01:08:47.702085
50	26	W214	2023	2025	2025-09-16 01:08:47.704857
51	27	W221	2006	2013	2025-09-16 01:08:47.708072
52	27	W222	2014	2020	2025-09-16 01:08:47.712668
53	27	W223	2021	2025	2025-09-16 01:08:47.715534
54	28	X253	2015	2022	2025-09-16 01:08:47.718516
55	28	X254	2022	2025	2025-09-16 01:08:47.721306
56	29	W166	2015	2019	2025-09-16 01:08:47.724318
57	29	W167	2019	2025	2025-09-16 01:08:47.729976
58	30	W176	2012	2018	2025-09-16 01:08:47.733045
59	30	W177	2018	2025	2025-09-16 01:08:47.735804
60	31	X156	2014	2020	2025-09-16 01:08:47.738732
61	31	H247	2020	2025	2025-09-16 01:08:47.743256
62	32	X247	2019	2025	2025-09-16 01:08:47.746447
63	33	W463	2004	2018	2025-09-16 01:08:47.74935
64	33	W464	2018	2025	2025-09-16 01:08:47.752073
65	34	V295	2022	2025	2025-09-16 01:08:47.755353
66	35	V297	2021	2025	2025-09-16 01:08:47.760185
67	36	C190	2015	2023	2025-09-16 01:08:47.763369
68	36	C192	2023	2025	2025-09-16 01:08:47.76616
69	37	X118	2013	2019	2025-09-16 01:08:47.769223
70	37	X118	2020	2025	2025-09-16 01:08:47.773147
71	38	R231	2012	2020	2025-09-16 01:08:47.776909
72	38	R232	2022	2025	2025-09-16 01:08:47.779671
73	39	B7	2004	2008	2025-09-16 01:08:47.783006
74	39	B7	2006	2008	2025-09-16 01:08:47.785792
75	39	B8	2008	2015	2025-09-16 01:08:47.789871
76	39	B9	2015	2023	2025-09-16 01:08:47.793262
77	39	B10	2023	2025	2025-09-16 01:08:47.796126
78	40	C6	2005	2011	2025-09-16 01:08:47.799031
79	40	C7	2011	2018	2025-09-16 01:08:47.801886
80	40	C8	2018	2025	2025-09-16 01:08:47.805836
81	41	D4	2010	2017	2025-09-16 01:08:47.809234
82	41	D5	2017	2025	2025-09-16 01:08:47.812225
83	42	8J	2006	2014	2025-09-16 01:08:47.815217
84	42	8S	2014	2023	2025-09-16 01:08:47.818052
85	43	8R	2009	2017	2025-09-16 01:08:47.823007
86	43	FY	2017	2023	2025-09-16 01:08:47.826048
87	43	FY	2020	2025	2025-09-16 01:08:47.828969
88	44	4L	2006	2015	2025-09-16 01:08:47.832095
89	44	4M	2015	2023	2025-09-16 01:08:47.834833
90	44	4M	2017	2023	2025-09-16 01:08:47.83897
91	45	GE	2019	2025	2025-09-16 01:08:47.842293
92	46	J1	2021	2025	2025-09-16 01:08:47.845596
93	47	C7	2013	2018	2025-09-16 01:08:47.848444
94	47	C8	2019	2025	2025-09-16 01:08:47.852409
95	48	8P	2004	2012	2025-09-16 01:08:47.85558
96	48	8V	2012	2020	2025-09-16 01:08:47.858403
97	48	8Y	2020	2025	2025-09-16 01:08:47.861498
98	49	8U	2011	2018	2025-09-16 01:08:47.864571
99	49	F3	2018	2025	2025-09-16 01:08:47.868841
100	50	42	2007	2015	2025-09-16 01:08:47.871891
101	50	Type 4S	2015	2023	2025-09-16 01:08:47.87446
102	51	GE	2020	2025	2025-09-16 01:08:47.878033
103	52	4M	2018	2025	2025-09-16 01:08:47.882128
104	53	FZ	2021	2025	2025-09-16 01:08:47.885514
105	54	8T	2007	2016	2025-09-16 01:08:47.888332
106	54	F5	2016	2023	2025-09-16 01:08:47.891117
107	55	4M	2020	2025	2025-09-16 01:08:47.89447
108	56	5代	2004	2009	2025-09-16 01:08:47.898757
109	56	5代	2006	2009	2025-09-16 01:08:47.90174
110	56	6代	2009	2013	2025-09-16 01:08:47.904524
111	56	6代	2010	2013	2025-09-16 01:08:47.907593
112	56	7代	2013	2020	2025-09-16 01:08:47.910901
113	56	7代	2014	2020	2025-09-16 01:08:47.915137
114	56	8代	2020	2025	2025-09-16 01:08:47.917928
115	56	8代	2021	2025	2025-09-16 01:08:47.920722
116	57	B6	2005	2011	2025-09-16 01:08:47.923717
117	57	B7	2011	2015	2025-09-16 01:08:47.927647
118	57	B8	2015	2023	2025-09-16 01:08:47.932983
119	57	B9	2023	2025	2025-09-16 01:08:47.937079
120	58	1代	2008	2016	2025-09-16 01:08:47.940694
121	58	2代	2016	2020	2025-09-16 01:08:47.944921
122	58	3代	2020	2025	2025-09-16 01:08:47.948151
123	59	1代	2018	2023	2025-09-16 01:08:47.951256
124	59	1代	2021	2025	2025-09-16 01:08:47.953992
125	60	1代	2004	2010	2025-09-16 01:08:47.957065
126	60	2代	2010	2015	2025-09-16 01:08:47.961547
127	60	3代	2015	2025	2025-09-16 01:08:47.964525
128	61	1代	2017	2025	2025-09-16 01:08:47.967542
129	62	1代	2021	2025	2025-09-16 01:08:47.970589
130	62	1代	2022	2025	2025-09-16 01:08:47.9733
131	63	4代	2004	2010	2025-09-16 01:08:47.978562
132	63	5代	2010	2020	2025-09-16 01:08:47.981501
133	63	5代	2020	2025	2025-09-16 01:08:47.984374
134	64	5代	2009	2017	2025-09-16 01:08:47.987353
135	64	6代	2018	2025	2025-09-16 01:08:47.991328
136	65	1代	2022	2025	2025-09-16 01:08:47.995111
137	66	1代	2023	2025	2025-09-16 01:08:47.998061
138	67	1代	2019	2025	2025-09-16 01:08:48.001791
139	68	1代	2005	2007	2025-09-16 01:08:48.004965
140	68	2代	2007	2014	2025-09-16 01:08:48.009442
141	68	2代	2011	2015	2025-09-16 01:08:48.012368
142	68	4代	2022	2025	2025-09-16 01:08:48.01521
143	69	1代	2005	2008	2025-09-16 01:08:48.018459
144	69	2代	2008	2013	2025-09-16 01:08:48.022372
145	69	3代	2013	2020	2025-09-16 01:08:48.026416
146	69	4代	2019	2024	2025-09-16 01:08:48.029336
147	69	5代	2024	2025	2025-09-16 01:08:48.032108
148	70	1代	2006	2010	2025-09-16 01:08:48.039089
149	71	1代	2005	2008	2025-09-16 01:08:48.042909
150	71	2代	2008	2015	2025-09-16 01:08:48.045797
151	71	3代	2015	2023	2025-09-16 01:08:48.048648
152	71	4代	2023	2025	2025-09-16 01:08:48.051514
153	72	1代	2010	2015	2025-09-16 01:08:48.056457
154	73	1代	2012	2019	2025-09-16 01:08:48.059952
155	74	1代	2017	2022	2025-09-16 01:08:48.063147
156	74	2代	2023	2025	2025-09-16 01:08:48.065871
157	75	1代	2018	2022	2025-09-16 01:08:48.07042
158	75	2代	2022	2025	2025-09-16 01:08:48.073319
159	76	1代	2019	2025	2025-09-16 01:08:48.076777
160	77	1代	2019	2022	2025-09-16 01:08:48.079823
161	77	2代	2023	2025	2025-09-16 01:08:48.082594
162	78	1代	2021	2025	2025-09-16 01:08:48.087089
163	78	1代	2023	2025	2025-09-16 01:08:48.089961
164	79	第一代(R50/R53)	2005	2006	2025-09-16 01:08:48.093589
165	79	第二代(R56)	2007	2013	2025-09-16 01:08:48.099183
166	80	R60	2011	2017	2025-09-16 01:08:48.10631
167	79	第三代(F56)	2014	2023	2025-09-16 01:08:48.10941
168	81	F54	2015	2023	2025-09-16 01:08:48.116237
169	82	F57	2016	2023	2025-09-16 01:08:48.119759
170	83	第三代(F56)	2020	2023	2025-09-16 01:08:48.122804
171	84	997	2005	2012	2025-09-16 01:08:48.126246
172	84	997	2006	2012	2025-09-16 01:08:48.132656
173	84	991	2012	2019	2025-09-16 01:08:48.135626
174	84	991	2013	2019	2025-09-16 01:08:48.14098
175	84	992	2019	2025	2025-09-16 01:08:48.144298
176	84	992	2020	2025	2025-09-16 01:08:48.148787
177	85	987	2005	2012	2025-09-16 01:08:48.15208
178	85	981	2012	2016	2025-09-16 01:08:48.154742
179	86	987	2005	2012	2025-09-16 01:08:48.157732
180	86	981	2012	2016	2025-09-16 01:08:48.161097
181	87	1代	2003	2010	2025-09-16 01:08:48.165363
182	87	2代	2010	2017	2025-09-16 01:08:48.168172
183	87	3代	2017	2025	2025-09-16 01:08:48.171143
184	88	1代	2019	2025	2025-09-16 01:08:48.174137
185	89	1代	2014	2021	2025-09-16 01:08:48.17888
186	90	1代	2009	2016	2025-09-16 01:08:48.18258
187	90	2代	2017	2021	2025-09-16 01:08:48.185321
188	91	982	2016	2020	2025-09-16 01:08:48.18831
189	92	1代	2019	2025	2025-09-16 01:08:48.195511
190	93	2代	2004	2008	2025-09-16 01:08:48.199686
191	93	3代	2011	2015	2025-09-16 01:08:48.202639
192	93	4代	2015	2018	2025-09-16 01:08:48.205421
193	93	4.5代	2018	2022	2025-09-16 01:08:48.208562
194	93	5代	2022	2025	2025-09-16 01:08:48.213089
195	94	2代	2013	2016	2025-09-16 01:08:48.216128
196	94	3代	2020	2025	2025-09-16 01:08:48.218885
197	95	4代	2007	2014	2025-09-16 01:08:48.224738
198	95	5代	2015	2022	2025-09-16 01:08:48.229282
199	95	6代	2023	2025	2025-09-16 01:08:48.232106
200	96	6代	2008	2013	2025-09-16 01:08:48.235156
201	96	7代	2014	2022	2025-09-16 01:08:48.237971
202	97	3代	2012	2019	2025-09-16 01:08:48.242503
203	97	4代	2019	2025	2025-09-16 01:08:48.245798
204	98	2代	2014	2023	2025-09-16 01:08:48.248885
205	99	2代	2022	2025	2025-09-16 01:08:48.251944
206	100	5代	2015	2023	2025-09-16 01:08:48.254857
207	100	6代	2024	2025	2025-09-16 01:08:48.26025
208	101	2代	2004	2008	2025-09-16 01:08:48.263558
209	102	1代	2014	2022	2025-09-16 01:08:48.266675
210	103	3代	2022	2025	2025-09-16 01:08:48.269771
211	104	5代	2022	2025	2025-09-16 01:08:48.273725
212	105	6代	2023	2025	2025-09-16 01:08:48.277771
213	106	2代	2004	2012	2025-09-16 01:08:48.281131
214	107	1代	2000	2009	2025-09-16 01:08:48.28681
215	107	2代	2010	2018	2025-09-16 01:08:48.290752
216	107	3代	2019	2025	2025-09-16 01:08:48.296724
217	108	2代	2006	2016	2025-09-16 01:08:48.302838
218	109	2代	2016	2025	2025-09-16 01:08:48.310341
219	110	1代	2004	2012	2025-09-16 01:08:48.313332
220	111	1代	2010	2018	2025-09-16 01:08:48.316279
221	111	2代	2019	2025	2025-09-16 01:08:48.320181
222	112	3代	2000	2007	2025-09-16 01:08:48.323703
223	113	1代	2008	2017	2025-09-16 01:08:48.327164
224	113	2代	2019	2025	2025-09-16 01:08:48.329974
225	113	2代	2017	2025	2025-09-16 01:08:48.33663
226	114	2代	2007	2016	2025-09-16 01:08:48.339924
227	115	1代	2002	2014	2025-09-16 01:08:48.343333
228	115	2代	2015	2025	2025-09-16 01:08:48.346053
229	116	1代	2018	2025	2025-09-16 01:08:48.349042
230	116	1代	2021	2025	2025-09-16 01:08:48.353314
231	117	1代	2006	2013	2025-09-16 01:08:48.356422
232	118	2代	2006	2013	2025-09-16 01:08:48.35984
233	119	ZN6	2012	2020	2025-09-16 01:08:48.363181
234	119	ZN8	2020	2025	2025-09-16 01:08:48.370305
235	120	9代	2004	2007	2025-09-16 01:08:48.373297
236	120	10代	2008	2013	2025-09-16 01:08:48.376343
237	120	11代	2014	2019	2025-09-16 01:08:48.379294
238	120	12代	2019	2023	2025-09-16 01:08:48.383391
239	120	12代	2021	2025	2025-09-16 01:08:48.386335
240	121	5代	2006	2011	2025-09-16 01:08:48.38945
241	121	6代	2012	2017	2025-09-16 01:08:48.392512
242	121	7代	2018	2023	2025-09-16 01:08:48.396059
243	121	8代	2023	2025	2025-09-16 01:08:48.401424
244	122	3代	2006	2012	2025-09-16 01:08:48.404906
245	122	4代	2013	2018	2025-09-16 01:08:48.407996
246	122	5代	2019	2025	2025-09-16 01:08:48.411378
247	123	1代	2006	2014	2025-09-16 01:08:48.419886
248	123	2代	2014	2020	2025-09-16 01:08:48.423022
249	123	3代	2020	2025	2025-09-16 01:08:48.426369
250	124	1代	2003	2007	2025-09-16 01:08:48.430702
251	124	2代	2008	2013	2025-09-16 01:08:48.433507
252	124	3代	2014	2023	2025-09-16 01:08:48.436352
253	124	4代	2023	2025	2025-09-16 01:08:48.43939
254	125	3代	2009	2015	2025-09-16 01:08:48.444185
255	125	4代	2016	2022	2025-09-16 01:08:48.447304
256	125	5代	2023	2025	2025-09-16 01:08:48.450219
257	126	2代	2009	2015	2025-09-16 01:08:48.453428
258	126	3代	2015	2023	2025-09-16 01:08:48.456239
259	126	4代	2023	2025	2025-09-16 01:08:48.461343
260	127	1代	2016	2022	2025-09-16 01:08:48.464677
261	127	2代	2022	2025	2025-09-16 01:08:48.467503
262	128	1代	2020	2025	2025-09-16 01:08:48.470673
263	128	1代	2023	2025	2025-09-16 01:08:48.474679
264	129	16代	2023	2025	2025-09-16 01:08:48.478288
265	130	8代	2019	2025	2025-09-16 01:08:48.481169
266	131	1代	2019	2025	2025-09-16 01:08:48.484169
267	132	1代	2022	2025	2025-09-16 01:08:48.48738
268	133	1代	2017	2023	2025-09-16 01:08:48.491913
269	134	1代	2023	2025	2025-09-16 01:08:48.495241
270	135	8代(FD1–FD3)	2006	2011	2025-09-16 01:08:48.498425
271	135	8代	2006	2011	2025-09-16 01:08:48.501211
272	135	9代(FA1–FA5)	2012	2016	2025-09-16 01:08:48.506027
273	135	9代	2012	2016	2025-09-16 01:08:48.510418
274	135	10代	2016	2021	2025-09-16 01:08:48.513588
275	135	10代	2017	2021	2025-09-16 01:08:48.516384
276	135	11代	2022	2025	2025-09-16 01:08:48.5193
277	135	11代	2023	2025	2025-09-16 01:08:48.523795
278	136	7代	2003	2008	2025-09-16 01:08:48.527302
279	136	8th (CL7–CM1)	2008	2013	2025-09-16 01:08:48.529936
280	136	8代	2008	2013	2025-09-16 01:08:48.532556
281	136	9代	2013	2019	2025-09-16 01:08:48.535579
282	136	10代	2018	2025	2025-09-16 01:08:48.542586
283	137	3代	2007	2011	2025-09-16 01:08:48.548439
284	137	4代	2012	2016	2025-09-16 01:08:48.552435
285	137	5代	2017	2022	2025-09-16 01:08:48.555703
286	137	6代	2023	2025	2025-09-16 01:08:48.558521
287	138	2代	2008	2014	2025-09-16 01:08:48.562033
288	138	3代	2014	2020	2025-09-16 01:08:48.564737
289	138	4代	2020	2025	2025-09-16 01:08:48.568864
290	139	1代	2015	2021	2025-09-16 01:08:48.57205
291	139	2代	2022	2025	2025-09-16 01:08:48.574802
292	140	4代	2004	2013	2025-09-16 01:08:48.58098
293	140	5代	2014	2020	2025-09-16 01:08:48.585459
294	140	6代	2021	2025	2025-09-16 01:08:48.588685
295	141	5代	2008	2014	2025-09-16 01:08:48.592086
296	141	6代	2014	2020	2025-09-16 01:08:48.59502
297	141	7代	2020	2025	2025-09-16 01:08:48.597831
298	142	AP2	2005	2009	2025-09-16 01:08:48.602052
299	143	4代	2005	2012	2025-09-16 01:08:48.60495
300	144	1代	2005	2008	2025-09-16 01:08:48.607835
301	144	2代	2009	2015	2025-09-16 01:08:48.611195
302	144	3代	2016	2022	2025-09-16 01:08:48.615
303	144	4代	2023	2025	2025-09-16 01:08:48.618267
304	145	1代	2005	2011	2025-09-16 01:08:48.621352
305	146	第一代	2003	2006	2025-09-16 01:08:48.624383
306	147	第二代	2007	2013	2025-09-16 01:08:48.627546
307	148	第一代	2013	2018	2025-09-16 01:08:48.631434
308	148	第二代	2019	2023	2025-09-16 01:08:48.634724
309	149	第一代	2008	2017	2025-09-16 01:08:48.637649
310	149	第二代	2018	2025	2025-09-16 01:08:48.640394
311	150	第一代	2013	2020	2025-09-16 01:08:48.643852
312	150	第二代	2021	2025	2025-09-16 01:08:48.647523
313	151	第一代	2003	2008	2025-09-16 01:08:48.650703
314	152	第二代	2009	2012	2025-09-16 01:08:48.653562
315	153	第二代	2009	2013	2025-09-16 01:08:48.657206
316	154	第一代	2014	2019	2025-09-16 01:08:48.660518
317	155	2代	2006	2013	2025-09-16 01:08:48.665206
318	155	3代	2013	2020	2025-09-16 01:08:48.667888
319	156	5代	2006	2012	2025-09-16 01:08:48.670933
320	156	6代	2012	2018	2025-09-16 01:08:48.673506
321	157	3代	2008	2015	2025-09-16 01:08:48.678222
322	157	4代	2015	2022	2025-09-16 01:08:48.681278
323	158	4代	2006	2017	2025-09-16 01:08:48.684132
324	158	5代	2017	2023	2025-09-16 01:08:48.686938
325	159	1代	2014	2021	2025-09-16 01:08:48.690206
326	159	2代	2021	2025	2025-09-16 01:08:48.694537
327	160	1代	2018	2025	2025-09-16 01:08:48.697611
328	161	1代	2017	2025	2025-09-16 01:08:48.703129
329	162	2代	2013	2019	2025-09-16 01:08:48.710671
330	163	3代	2019	2023	2025-09-16 01:08:48.713625
331	164	2代	2012	2018	2025-09-16 01:08:48.716494
332	165	3代	2018	2023	2025-09-16 01:08:48.719473
333	166	1代	2012	2017	2025-09-16 01:08:48.723435
334	167	2代	2017	2023	2025-09-16 01:08:48.727344
335	168	1代	2019	2023	2025-09-16 01:08:48.730346
336	169	1代	2015	2020	2025-09-16 01:08:48.733366
337	170	3代	2015	2023	2025-09-16 01:08:48.736216
338	171	C11	2005	2011	2025-09-16 01:08:48.740482
339	171	C12	2011	2019	2025-09-16 01:08:48.743838
340	172	B17	2013	2019	2025-09-16 01:08:48.746868
341	173	L33	2013	2018	2025-09-16 01:08:48.749896
342	174	T31	2007	2013	2025-09-16 01:08:48.752794
343	174	T32	2013	2021	2025-09-16 01:08:48.757942
344	175	F15	2010	2019	2025-09-16 01:08:48.761191
345	176	Z51	2009	2014	2025-09-16 01:08:48.764073
346	177	P15	2017	2025	2025-09-16 01:08:48.767145
347	178	R35	2008	2022	2025-09-16 01:08:48.77102
348	179	Z33	2003	2009	2025-09-16 01:08:48.774449
349	180	Z34	2009	2020	2025-09-16 01:08:48.778019
350	181	GD	2006	2011	2025-09-16 01:08:48.781257
351	181	GR	2011	2014	2025-09-16 01:08:48.783943
352	181	GV/GP	2012	2016	2025-09-16 01:08:48.78779
353	182	SH	2008	2013	2025-09-16 01:08:48.791076
354	182	SJ	2013	2018	2025-09-16 01:08:48.794309
355	182	SK	2018	2022	2025-09-16 01:08:48.797148
356	183	BP	2005	2009	2025-09-16 01:08:48.800147
357	183	BL	2009	2014	2025-09-16 01:08:48.803723
358	184	VAB	2014	2021	2025-09-16 01:08:48.806998
359	185	ZN6	2012	2020	2025-09-16 01:08:48.810417
\.


--
-- Data for Name: makes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.makes (id, name, country, created_at) FROM stdin;
1	BMW	\N	2025-09-16 01:08:47.498709
2	Benz	\N	2025-09-16 01:08:47.681903
3	Audi	\N	2025-09-16 01:08:47.781618
4	VW	\N	2025-09-16 01:08:47.89714
5	Skoda	\N	2025-09-16 01:08:48.003546
6	Mini	\N	2025-09-16 01:08:48.091934
7	Porsche	\N	2025-09-16 01:08:48.12448
8	Ford	\N	2025-09-16 01:08:48.197909
9	Volvo	\N	2025-09-16 01:08:48.279674
10	Toyota	\N	2025-09-16 01:08:48.361764
11	Honda	\N	2025-09-16 01:08:48.496988
12	Infiniti	\N	2025-09-16 01:08:48.623065
13	Lexus	\N	2025-09-16 01:08:48.663623
14	Mazda	\N	2025-09-16 01:08:48.708716
15	Nissan	\N	2025-09-16 01:08:48.737843
16	Subaru	\N	2025-09-16 01:08:48.779737
\.


--
-- Data for Name: models; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.models (id, make_id, name, external_code, created_at) FROM stdin;
1	1	1 Series	\N	2025-09-16 01:08:47.51219
2	1	3 Series	\N	2025-09-16 01:08:47.531925
3	1	5 Series	\N	2025-09-16 01:08:47.555193
4	1	7 Series	\N	2025-09-16 01:08:47.567396
5	1	X3	\N	2025-09-16 01:08:47.57843
6	1	X5	\N	2025-09-16 01:08:47.585783
7	1	Z4	\N	2025-09-16 01:08:47.597142
8	1	i3	\N	2025-09-16 01:08:47.605176
9	1	i8	\N	2025-09-16 01:08:47.60826
10	1	iX	\N	2025-09-16 01:08:47.611656
11	1	M3	\N	2025-09-16 01:08:47.615721
12	1	M5	\N	2025-09-16 01:08:47.624483
13	1	X3 M	\N	2025-09-16 01:08:47.631909
14	1	X5 M	\N	2025-09-16 01:08:47.635318
15	1	X6 M	\N	2025-09-16 01:08:47.638223
16	1	2 Series	\N	2025-09-16 01:08:47.641473
17	1	4 Series	\N	2025-09-16 01:08:47.645105
18	1	6 Series	\N	2025-09-16 01:08:47.652179
19	1	8 Series	\N	2025-09-16 01:08:47.655187
20	1	X4	\N	2025-09-16 01:08:47.658222
21	1	X7	\N	2025-09-16 01:08:47.662681
22	1	i4	\N	2025-09-16 01:08:47.66593
23	1	M4	\N	2025-09-16 01:08:47.668766
24	1	XM	\N	2025-09-16 01:08:47.674831
25	2	C-Class	\N	2025-09-16 01:08:47.682532
26	2	E-Class	\N	2025-09-16 01:08:47.695211
27	2	S-Class	\N	2025-09-16 01:08:47.707082
28	2	GLC	\N	2025-09-16 01:08:47.717709
29	2	GLE	\N	2025-09-16 01:08:47.723525
30	2	A-Class	\N	2025-09-16 01:08:47.732283
31	2	GLA	\N	2025-09-16 01:08:47.737955
32	2	GLB	\N	2025-09-16 01:08:47.745696
33	2	G-Class	\N	2025-09-16 01:08:47.748613
34	2	EQE	\N	2025-09-16 01:08:47.754596
35	2	EQS	\N	2025-09-16 01:08:47.759116
36	2	AMG GT	\N	2025-09-16 01:08:47.762557
37	2	CLA	\N	2025-09-16 01:08:47.768466
38	2	SL	\N	2025-09-16 01:08:47.776003
39	3	A4	\N	2025-09-16 01:08:47.782236
40	3	A6	\N	2025-09-16 01:08:47.798286
41	3	A8	\N	2025-09-16 01:08:47.808287
42	3	TT	\N	2025-09-16 01:08:47.814466
43	3	Q5	\N	2025-09-16 01:08:47.82217
44	3	Q7	\N	2025-09-16 01:08:47.831305
45	3	e-tron	\N	2025-09-16 01:08:47.841353
46	3	e-tron GT	\N	2025-09-16 01:08:47.844804
47	3	RS6	\N	2025-09-16 01:08:47.847728
48	3	A3	\N	2025-09-16 01:08:47.854784
49	3	Q3	\N	2025-09-16 01:08:47.863759
50	3	R8	\N	2025-09-16 01:08:47.871136
51	3	e-tron FE	\N	2025-09-16 01:08:47.877226
52	3	Q8	\N	2025-09-16 01:08:47.880297
53	3	Q4 e-tron	\N	2025-09-16 01:08:47.884763
54	3	A5	\N	2025-09-16 01:08:47.887622
55	3	RS Q8	\N	2025-09-16 01:08:47.893676
56	4	Golf	\N	2025-09-16 01:08:47.897787
57	4	Passat	\N	2025-09-16 01:08:47.92295
58	4	Tiguan	\N	2025-09-16 01:08:47.939865
59	4	T-Roc	\N	2025-09-16 01:08:47.950432
60	4	Touran	\N	2025-09-16 01:08:47.956273
61	4	Arteon	\N	2025-09-16 01:08:47.966728
62	4	ID.4	\N	2025-09-16 01:08:47.96984
63	4	Caddy	\N	2025-09-16 01:08:47.977757
64	4	Polo	\N	2025-09-16 01:08:47.986569
65	4	Taigo	\N	2025-09-16 01:08:47.994322
66	4	ID.3	\N	2025-09-16 01:08:47.997331
67	4	T-Cross	\N	2025-09-16 01:08:48.000995
68	5	Fabia	\N	2025-09-16 01:08:48.004162
69	5	Octavia	\N	2025-09-16 01:08:48.017529
70	5	Roomster	\N	2025-09-16 01:08:48.038069
71	5	Superb	\N	2025-09-16 01:08:48.041807
72	5	Yeti	\N	2025-09-16 01:08:48.05565
73	5	Rapid	\N	2025-09-16 01:08:48.058932
74	5	Kodiaq	\N	2025-09-16 01:08:48.062396
75	5	Karoq	\N	2025-09-16 01:08:48.069334
76	5	Kamiq	\N	2025-09-16 01:08:48.075897
77	5	Scala	\N	2025-09-16 01:08:48.079021
78	5	Enyaq	\N	2025-09-16 01:08:48.086252
79	6	Mini Hatch	\N	2025-09-16 01:08:48.09277
80	6	Mini Countryman	\N	2025-09-16 01:08:48.105511
81	6	Mini Clubman	\N	2025-09-16 01:08:48.114306
82	6	Mini Convertible	\N	2025-09-16 01:08:48.11887
83	6	Mini Electric	\N	2025-09-16 01:08:48.122024
84	7	911	\N	2025-09-16 01:08:48.12517
85	7	Boxster	\N	2025-09-16 01:08:48.151257
86	7	Cayman	\N	2025-09-16 01:08:48.156997
87	7	Cayenne	\N	2025-09-16 01:08:48.164326
88	7	Cayenne Coupe	\N	2025-09-16 01:08:48.17338
89	7	Macan	\N	2025-09-16 01:08:48.176956
90	7	Panamera	\N	2025-09-16 01:08:48.181776
91	7	718	\N	2025-09-16 01:08:48.187563
92	7	Taycan	\N	2025-09-16 01:08:48.193588
93	8	Focus	\N	2025-09-16 01:08:48.198586
94	8	Kuga	\N	2025-09-16 01:08:48.215397
95	8	Mondeo	\N	2025-09-16 01:08:48.223899
96	8	Fiesta	\N	2025-09-16 01:08:48.234359
97	8	Ranger	\N	2025-09-16 01:08:48.240406
98	8	Tourneo Custom	\N	2025-09-16 01:08:48.248131
99	8	Tourneo Connect	\N	2025-09-16 01:08:48.251218
100	8	Mustang	\N	2025-09-16 01:08:48.25411
101	8	Escape	\N	2025-09-16 01:08:48.26273
102	8	EcoSport	\N	2025-09-16 01:08:48.265904
103	8	KUGA PHEV	\N	2025-09-16 01:08:48.269037
104	8	Focus Active	\N	2025-09-16 01:08:48.272014
105	8	Explorer	\N	2025-09-16 01:08:48.276916
106	9	S40	\N	2025-09-16 01:08:48.280362
107	9	S60	\N	2025-09-16 01:08:48.28599
108	9	S80	\N	2025-09-16 01:08:48.302086
109	9	S90	\N	2025-09-16 01:08:48.309399
110	9	V50	\N	2025-09-16 01:08:48.31262
111	9	V60	\N	2025-09-16 01:08:48.315523
112	9	V70	\N	2025-09-16 01:08:48.322912
113	9	XC60	\N	2025-09-16 01:08:48.326342
114	9	XC70	\N	2025-09-16 01:08:48.339135
115	9	XC90	\N	2025-09-16 01:08:48.342266
116	9	XC40	\N	2025-09-16 01:08:48.348274
117	9	C30	\N	2025-09-16 01:08:48.355639
118	9	C70	\N	2025-09-16 01:08:48.358853
119	10	86	\N	2025-09-16 01:08:48.36243
120	10	Corolla Altis	\N	2025-09-16 01:08:48.372549
121	10	Camry	\N	2025-09-16 01:08:48.388627
122	10	RAV4	\N	2025-09-16 01:08:48.404016
123	10	Yaris	\N	2025-09-16 01:08:48.418939
124	10	Vios	\N	2025-09-16 01:08:48.429875
125	10	Prius	\N	2025-09-16 01:08:48.442008
126	10	Alphard	\N	2025-09-16 01:08:48.452574
127	10	Sienta	\N	2025-09-16 01:08:48.463849
128	10	Corolla Cross	\N	2025-09-16 01:08:48.46991
129	10	Crown	\N	2025-09-16 01:08:48.477542
130	10	Hilux	\N	2025-09-16 01:08:48.480414
131	10	Granvia	\N	2025-09-16 01:08:48.483378
132	10	bZ4X	\N	2025-09-16 01:08:48.486634
133	10	C-HR	\N	2025-09-16 01:08:48.4908
134	10	Yaris Cross	\N	2025-09-16 01:08:48.494492
135	11	Civic	\N	2025-09-16 01:08:48.497626
136	11	Accord	\N	2025-09-16 01:08:48.52653
137	11	CR-V	\N	2025-09-16 01:08:48.547704
138	11	Fit	\N	2025-09-16 01:08:48.561251
139	11	HR-V	\N	2025-09-16 01:08:48.571272
140	11	Odyssey	\N	2025-09-16 01:08:48.580176
141	11	City	\N	2025-09-16 01:08:48.591193
142	11	S2000	\N	2025-09-16 01:08:48.601268
143	11	Legend	\N	2025-09-16 01:08:48.604189
144	11	Pilot	\N	2025-09-16 01:08:48.607112
145	11	Element	\N	2025-09-16 01:08:48.620564
146	12	G35	\N	2025-09-16 01:08:48.623657
147	12	G37	\N	2025-09-16 01:08:48.626797
148	12	Q50	\N	2025-09-16 01:08:48.629746
149	12	QX50	\N	2025-09-16 01:08:48.636878
150	12	QX60	\N	2025-09-16 01:08:48.64313
151	12	FX35	\N	2025-09-16 01:08:48.649954
152	12	FX37	\N	2025-09-16 01:08:48.652828
153	12	FX50	\N	2025-09-16 01:08:48.65571
154	12	Q70	\N	2025-09-16 01:08:48.659747
155	13	IS	\N	2025-09-16 01:08:48.664406
156	13	ES	\N	2025-09-16 01:08:48.67022
157	13	RX	\N	2025-09-16 01:08:48.677244
158	13	LS	\N	2025-09-16 01:08:48.683394
159	13	NX	\N	2025-09-16 01:08:48.689453
160	13	UX	\N	2025-09-16 01:08:48.69687
161	13	LC	\N	2025-09-16 01:08:48.702355
162	14	BM系列	\N	2025-09-16 01:08:48.709626
163	14	BP系列	\N	2025-09-16 01:08:48.7129
164	14	GJ系列	\N	2025-09-16 01:08:48.7157
165	14	GL系列	\N	2025-09-16 01:08:48.718725
166	14	KE系列	\N	2025-09-16 01:08:48.721829
167	14	KF系列	\N	2025-09-16 01:08:48.726491
168	14	DM系列	\N	2025-09-16 01:08:48.729617
169	14	DK系列	\N	2025-09-16 01:08:48.732612
170	14	ND系列	\N	2025-09-16 01:08:48.735493
171	15	Tiida	\N	2025-09-16 01:08:48.739535
172	15	Sentra	\N	2025-09-16 01:08:48.746148
173	15	Altima	\N	2025-09-16 01:08:48.749142
174	15	X-Trail	\N	2025-09-16 01:08:48.752086
175	15	Juke	\N	2025-09-16 01:08:48.76045
176	15	Murano	\N	2025-09-16 01:08:48.763365
177	15	Kicks	\N	2025-09-16 01:08:48.766434
178	15	GT-R	\N	2025-09-16 01:08:48.769395
179	15	350Z	\N	2025-09-16 01:08:48.773729
180	15	370Z	\N	2025-09-16 01:08:48.777289
181	16	Impreza	\N	2025-09-16 01:08:48.780494
182	16	Forester	\N	2025-09-16 01:08:48.790346
183	16	Legacy	\N	2025-09-16 01:08:48.799286
184	16	WRX	\N	2025-09-16 01:08:48.80625
185	16	BRZ	\N	2025-09-16 01:08:48.809512
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_items (id, order_id, part_id, quantity, price_twd, created_at) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (id, garage_id, status, created_at) FROM stdin;
\.


--
-- Data for Name: part_compatibilities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.part_compatibilities (id, part_id, vehicle_variant_id, note, created_at) FROM stdin;
\.


--
-- Data for Name: parts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parts (id, sku, name, category, brand, price_twd, cost_twd, currency, weight_kg, vat_included, stock_qty, description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: price_rules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.price_rules (id, name, role, scope_type, scope_value, rule_type, value, priority, active, valid_from, valid_to, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, display_name, email, role, password_hash, created_at) FROM stdin;
\.


--
-- Data for Name: vehicle_variants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vehicle_variants (id, model_id, generation_id, variant_name, year_from, year_to, engine_code, displacement_cc, power_ps, intake_type, drive_type, front_suspension, rear_suspension, fuel_type, special_tech, created_at) FROM stdin;
1	1	1	130i	2004	2011	N52	2996	265	自然進氣	RWD	麥花臣	多連桿	汽油	\N	2025-09-16 01:08:47.525723
2	2	2	320i	2005	2012	N46	1995	150	自然進氣	RWD	麥花臣	多連桿	汽油	\N	2025-09-16 01:08:47.534913
3	2	2	335i	2007	2010	N54	2979	306	雙渦輪增壓	RWD	麥花臣	多連桿	汽油	\N	2025-09-16 01:08:47.540088
4	2	4	320i	2012	2018	B48	1998	184	渦輪增壓	RWD	雙接頭彈簧柱	多連桿	汽油	\N	2025-09-16 01:08:47.543924
5	2	4	340i	2015	2019	B58	2998	326	渦輪增壓	AWD	雙接頭彈簧柱	多連桿	汽油	\N	2025-09-16 01:08:47.546656
6	2	6	330i	2019	2023	B48B20	1998	258	渦輪增壓	AWD	雙接頭彈簧柱	多連桿	汽油	\N	2025-09-16 01:08:47.549592
7	2	6	M340i	2019	2023	B58B30	2998	387	渦輪增壓	AWD	雙接頭彈簧柱(M款)	多連桿(M款)	汽油	\N	2025-09-16 01:08:47.552437
8	3	7	530i	2003	2010	N52	2996	258	自然進氣	RWD	雙A臂	整體式多連桿	汽油	\N	2025-09-16 01:08:47.557188
9	3	8	535i	2010	2016	N55	2979	306	渦輪增壓	RWD	雙接頭彈簧柱	多連桿	汽油	\N	2025-09-16 01:08:47.56057
10	3	9	540i	2017	2023	B58	2998	340	渦輪增壓	AWD	雙接頭彈簧柱	多連桿	汽油	\N	2025-09-16 01:08:47.563417
11	3	9	M550i	2017	2023	N63	4395	530	雙渦輪增壓	AWD	雙A臂(M款)	多連桿(M款)	汽油	\N	2025-09-16 01:08:47.565991
12	4	10	750i	2008	2015	N63	4395	450	雙渦輪增壓	RWD	雙接頭彈簧柱	整體式多連桿	汽油	\N	2025-09-16 01:08:47.570511
13	4	11	740i	2015	2022	B58	2998	326	渦輪增壓	RWD	雙接頭彈簧柱	多連桿	汽油	\N	2025-09-16 01:08:47.573859
14	4	11	M760i	2016	2022	N74	6592	610	雙渦輪增壓	AWD	雙接頭彈簧柱	多連桿	汽油	\N	2025-09-16 01:08:47.577015
15	5	13	xDrive35i	2010	2017	N55	2979	306	渦輪增壓	AWD	麥花臣	多連桿	汽油	\N	2025-09-16 01:08:47.580178
16	5	14	X3 M40i	2017	2023	B58	2998	360	渦輪增壓	AWD	雙接頭彈簧柱	多連桿	汽油	\N	2025-09-16 01:08:47.583137
17	6	15	xDrive50i	2006	2013	N63	4395	408	雙渦輪增壓	AWD	雙A臂	整體式多連桿	汽油	\N	2025-09-16 01:08:47.588194
18	6	16	X5 M	2013	2018	S63	4395	575	雙渦輪增壓	AWD	雙A臂(M款)	多連桿(M款)	汽油	\N	2025-09-16 01:08:47.591766
19	6	17	X5 M50i	2018	2023	N63	4395	530	雙渦輪增壓	AWD	雙A臂	多連桿	汽油	\N	2025-09-16 01:08:47.595432
20	7	18	Z4 sDrive35i	2009	2016	N54	2979	306	雙渦輪增壓	RWD	麥花臣	中央控制臂	汽油	\N	2025-09-16 01:08:47.599186
21	7	19	Z4 M40i	2018	2023	B58	2998	340	渦輪增壓	RWD	麥花臣	多連桿	汽油	\N	2025-09-16 01:08:47.60374
22	8	20	i3	2013	2022	電動	\N	170	電動	RWD	麥花臣	拖曳臂	純電	\N	2025-09-16 01:08:47.606907
23	9	21	i8	2014	2020	B38	1499	362	渦輪增壓	AWD	雙接頭彈簧柱	多連桿	汽油	\N	2025-09-16 01:08:47.610276
24	10	22	iX xDrive50	2021	2023	電動	\N	523	電動	AWD	雙接頭彈簧柱	多連桿	純電	\N	2025-09-16 01:08:47.613331
25	11	23	M3	2007	2013	S65	3999	420	自然進氣	RWD	雙A臂	多連桿	汽油	\N	2025-09-16 01:08:47.617707
26	11	24	M3	2014	2018	S55	2979	431	雙渦輪增壓	RWD	雙A臂(M款)	多連桿(M款)	汽油	\N	2025-09-16 01:08:47.620579
27	11	25	M3 Competition	2020	2023	S58	2993	510	雙渦輪增壓	AWD	雙A臂(M款)	多連桿(M款)	汽油	\N	2025-09-16 01:08:47.623164
28	12	26	M5	2011	2016	S63	4395	560	雙渦輪增壓	RWD	雙A臂	多連桿	汽油	\N	2025-09-16 01:08:47.626516
29	12	27	M5 Competition	2017	2023	S63	4395	625	雙渦輪增壓	AWD	雙A臂(M款)	多連桿(M款)	汽油	\N	2025-09-16 01:08:47.629495
30	13	28	X3 M Competition	2019	2023	S58	2993	510	雙渦輪增壓	AWD	雙A臂(M款)	多連桿(M款)	汽油	\N	2025-09-16 01:08:47.633921
31	14	29	X5 M	2013	2018	S63	4395	575	雙渦輪增壓	AWD	雙A臂(M款)	多連桿(M款)	汽油	\N	2025-09-16 01:08:47.636964
32	15	30	X6 M Competition	2019	2023	S63	4395	625	雙渦輪增壓	AWD	雙A臂(M款)	多連桿(M款)	汽油	\N	2025-09-16 01:08:47.640018
33	16	31	M235i xDrive	2020	2023	B48	1998	306	渦輪增壓	AWD	麥花臣	多連桿	汽油	\N	2025-09-16 01:08:47.64372
34	17	32	440i	2014	2020	B58	2998	326	渦輪增壓	RWD	雙接頭彈簧柱	多連桿	汽油	\N	2025-09-16 01:08:47.647794
35	17	33	M440i	2020	2023	B58B30	2998	387	渦輪增壓	AWD	雙接頭彈簧柱(M款)	多連桿(M款)	汽油	\N	2025-09-16 01:08:47.650863
36	18	34	640i GT	2017	2020	B58	2998	340	渦輪增壓	AWD	雙接頭彈簧柱	多連桿	汽油	\N	2025-09-16 01:08:47.653867
37	19	35	M850i	2018	2023	N63	4395	530	雙渦輪增壓	AWD	雙接頭彈簧柱	多連桿	汽油	\N	2025-09-16 01:08:47.656888
38	20	36	X4 M40i	2018	2023	B58	2998	360	渦輪增壓	AWD	雙接頭彈簧柱	多連桿	汽油	\N	2025-09-16 01:08:47.660265
39	21	37	X7 M50i	2018	2023	N63	4395	530	雙渦輪增壓	AWD	雙A臂	多連桿	汽油	\N	2025-09-16 01:08:47.664628
40	22	38	i4 M50	2021	2023	電動	\N	544	電動	AWD	雙接頭彈簧柱	多連桿	純電	\N	2025-09-16 01:08:47.667483
41	23	39	M4 CSL	2022	2023	S58	2993	550	雙渦輪增壓	RWD	雙A臂(M款)	多連桿(M款)	汽油	\N	2025-09-16 01:08:47.670464
42	12	27	M5 CS	2021	2022	S63	4395	635	雙渦輪增壓	AWD	雙A臂(M款)	多連桿(M款)	汽油	\N	2025-09-16 01:08:47.673454
43	24	41	XM Label Red	2023	2023	S68	4395	748	雙渦輪增壓+PHEV	AWD	雙A臂(主動式)	多連桿(主動式)	汽油	\N	2025-09-16 01:08:47.676813
44	2	42	M3 CSL	2003	2004	S54	3246	360	自然進氣	RWD	麥花臣	多連桿	汽油	\N	2025-09-16 01:08:47.680972
45	25	43	C200	2004	2007	M271	1796	163	機械增壓	RWD	麥花臣	多連桿	汽油	KOMPRESSOR	2025-09-16 01:08:47.684228
46	25	44	C250	2008	2014	M271	1796	204	渦輪增壓	RWD	三連桿	多連桿	汽油	BlueEFFICIENCY	2025-09-16 01:08:47.686888
47	25	45	C200	2015	2021	M274	1991	184	渦輪增壓	RWD	多連桿	多連桿	汽油	ECO Start/Stop	2025-09-16 01:08:47.689635
48	25	46	C200	2021	2025	M254	1499	204	渦輪增壓	RWD	多連桿	多連桿	汽油	48V EQ Boost	2025-09-16 01:08:47.692993
49	26	47	E200K	2004	2009	M271	1796	163	機械增壓	RWD	雙A臂	多連桿	汽油	氣壓懸吊(選配)	2025-09-16 01:08:47.697237
50	26	48	E250	2009	2016	M271	1796	204	渦輪增壓	4MATIC	三連桿	多連桿	汽油	AGILITY CONTROL	2025-09-16 01:08:47.700153
51	26	49	E200	2016	2023	M274	1991	184	渦輪增壓	RWD	多連桿	多連桿	汽油	氣壓懸吊(選配)	2025-09-16 01:08:47.702955
52	26	50	E200	2023	2025	M254	1999	204	渦輪增壓	RWD	多連桿	多連桿	汽油	48V輕油電	2025-09-16 01:08:47.705715
53	27	51	S350L	2006	2013	M272	3498	272	自然進氣	RWD	雙A臂	多連桿	汽油	AIRMATIC氣壓懸吊	2025-09-16 01:08:47.710279
54	27	52	S450L	2014	2020	M276	2996	367	渦輪增壓	4MATIC	雙A臂	多連桿	汽油	MAGIC BODY CONTROL	2025-09-16 01:08:47.713611
55	27	53	S500L	2021	2025	M256	2999	435	渦輪增壓	4MATIC	雙A臂	多連桿	汽油	48V+ISG整合式啟動發電機	2025-09-16 01:08:47.716396
56	28	54	GLC200	2015	2022	M274	1991	184	渦輪增壓	4MATIC	麥花臣	多連桿	汽油	越野模式	2025-09-16 01:08:47.719426
57	28	55	GLC300e	2022	2025	M254	1999	313	渦輪增壓	4MATIC	多連桿	多連桿	插電混動	31.2kWh電池	2025-09-16 01:08:47.722206
58	29	56	GLE350d	2015	2019	OM642	2987	258	渦輪增壓	4MATIC	雙A臂	多連桿	柴油	ADS主動懸吊	2025-09-16 01:08:47.726305
59	29	57	GLE450	2019	2025	M256	2999	367	渦輪增壓	4MATIC	E-ACTIVE BODY	E-ACTIVE BODY	汽油	48V主動式懸吊	2025-09-16 01:08:47.730921
60	30	58	A180	2012	2018	M270	1595	122	渦輪增壓	FWD	麥花臣	扭力樑	汽油	MBUX(2018)	2025-09-16 01:08:47.733889
61	30	59	A200	2018	2025	M282	1332	163	渦輪增壓	FWD	麥花臣	扭力樑	汽油	MBUX系統	2025-09-16 01:08:47.736638
62	31	60	GLA200	2014	2020	M270	1595	156	渦輪增壓	4MATIC	麥花臣	多連桿	汽油	越野模式	2025-09-16 01:08:47.739899
63	31	61	GLA250	2020	2025	M260	1991	224	渦輪增壓	4MATIC	麥花臣	多連桿	汽油	MBUX擴增實境	2025-09-16 01:08:47.7443
64	32	62	GLB200	2019	2025	M282	1332	163	渦輪增壓	FWD	麥花臣	扭力樑	汽油	7人座配置	2025-09-16 01:08:47.747307
65	33	63	G500	2004	2018	M273	5461	388	自然進氣	4MATIC	固定軸	固定軸	汽油	三差速鎖定	2025-09-16 01:08:47.75026
66	33	64	G400d	2018	2025	OM656	2925	330	渦輪增壓	4MATIC	雙A臂	固定軸	柴油	ECO Start/Stop	2025-09-16 01:08:47.753213
67	34	65	EQE350+	2022	2025	電動	\N	292	電動	RWD	四連桿	多連桿	純電	90.6kWh電池	2025-09-16 01:08:47.757241
68	35	66	EQS450+	2021	2025	電動	\N	333	電動	RWD	四連桿	多連桿	純電	107.8kWh電池	2025-09-16 01:08:47.761137
69	36	67	AMG GT S	2015	2023	M178	3982	522	渦輪增壓	RWD	雙A臂	雙A臂	汽油	乾式油底殼	2025-09-16 01:08:47.764235
70	36	68	AMG GT 63 S	2023	2025	M177	3982	639	渦輪增壓	4MATIC+	雙A臂	雙A臂	汽油	主動式後軸轉向	2025-09-16 01:08:47.7671
71	37	69	CLA200	2013	2019	M270	1595	156	渦輪增壓	FWD	麥花臣	多連桿	汽油	四門轎跑	2025-09-16 01:08:47.770132
72	37	69	CLA35 AMG	2020	2025	M260	1991	306	渦輪增壓	4MATIC	麥花臣	多連桿	汽油	AMG Performance	2025-09-16 01:08:47.774173
73	38	71	SL500	2012	2020	M278	4663	435	渦輪增壓	RWD	雙A臂	多連桿	汽油	主動式液壓車頂	2025-09-16 01:08:47.777805
74	38	72	SL55 AMG	2022	2025	M177	3982	476	渦輪增壓	4MATIC+	雙A臂	多連桿	汽油	主動式後軸轉向	2025-09-16 01:08:47.78062
75	39	73	A4 1.8T	2004	2008	EA113	1781	163	渦輪增壓	FWD	雙A臂	梯型多連桿	汽油	K03渦輪	2025-09-16 01:08:47.78388
76	39	73	A4 2.0T FSI	2006	2008	EA113	1984	200	渦輪增壓	FWD	雙A臂	梯型多連桿	汽油	FSI直噴	2025-09-16 01:08:47.786671
77	39	75	A4 2.0TFSI	2008	2015	EA888	1984	180	渦輪增壓	quattro	五連桿	梯型多連桿	汽油	AVS可變氣門	2025-09-16 01:08:47.79098
78	39	76	A4 40 TFSI	2015	2023	EA888 Gen3	1984	190	渦輪增壓	quattro	五連桿	五連桿	汽油	B循環技術	2025-09-16 01:08:47.794193
79	39	77	A4 45 TFSI	2023	2025	EA888 Evo4	1984	265	渦輪增壓	quattro	五連桿	五連桿	汽油	12V輕油電	2025-09-16 01:08:47.796995
80	40	78	A6 2.8 FSI	2005	2011	BAE	2773	220	自然進氣	quattro	雙A臂	雙A臂	汽油	AVS可變氣門	2025-09-16 01:08:47.799929
81	40	79	A6 35 TDI	2011	2018	EA288	1968	190	渦輪增壓	quattro	五連桿	梯型多連桿	柴油	雙渦輪增壓	2025-09-16 01:08:47.802713
82	40	80	A6 45 TFSI	2018	2025	EA888 Gen3	1984	245	渦輪增壓	quattro	五連桿	五連桿	汽油	12V輕油電	2025-09-16 01:08:47.806838
83	41	81	A8L 3.0T	2010	2017	CRE	2995	290	機械增壓	quattro	雙A臂	雙A臂	汽油	全鋁合金車身	2025-09-16 01:08:47.810289
84	41	82	A8L 55 TFSI	2017	2025	EA839	2995	340	渦輪增壓	quattro	雙A臂	雙A臂	汽油	48V輕油電	2025-09-16 01:08:47.813157
85	42	83	TT 2.0TFSI	2006	2014	EA113	1984	200	渦輪增壓	quattro	麥花臣	四連桿	汽油	ASF鋁合金車體	2025-09-16 01:08:47.816078
86	42	84	TT S	2014	2023	EA888	1984	310	渦輪增壓	quattro	麥花臣	四連桿	汽油	虛擬座艙	2025-09-16 01:08:47.820432
87	43	85	Q5 2.0TFSI	2009	2017	EA888	1984	180	渦輪增壓	quattro	五連桿	梯型多連桿	汽油	quattro ultra	2025-09-16 01:08:47.823912
88	43	86	Q5 45 TFSI	2017	2023	EA888 Gen3	1984	252	渦輪增壓	quattro	五連桿	五連桿	汽油	主動氣壓懸吊	2025-09-16 01:08:47.827021
89	43	86	Q5 55 TFSI e	2020	2025	EA888 + PHEV	1984	367	渦輪增壓	quattro	五連桿	五連桿	插電混動	17.9kWh電池	2025-09-16 01:08:47.829945
90	44	88	Q7 3.0 TDI	2006	2015	ASB	2967	233	渦輪增壓	quattro	雙A臂	雙A臂	柴油	可調氣壓懸吊	2025-09-16 01:08:47.832963
91	44	89	Q7 45 TDI	2015	2023	EA897	2967	249	渦輪增壓	quattro	雙A臂	雙A臂	柴油	48V輕油電	2025-09-16 01:08:47.836632
92	44	89	Q7 e-tron	2017	2023	EA888 + PHEV	1984	367	渦輪增壓	quattro	雙A臂	雙A臂	插電混動	quattro四驅	2025-09-16 01:08:47.839932
93	45	91	e-tron 55	2019	2025	電動	\N	408	電動	quattro	雙A臂	多連桿	純電	95kWh電池	2025-09-16 01:08:47.843454
94	46	92	e-tron GT	2021	2025	電動	\N	530	電動	quattro	雙A臂	多連桿	純電	800V架構	2025-09-16 01:08:47.846459
95	47	93	RS6 Avant	2013	2018	EA824	3993	560	雙渦輪增壓	quattro	雙A臂	雙A臂	汽油	動態駕馭控制	2025-09-16 01:08:47.849337
96	47	94	RS6 Avant	2019	2025	EA825	3996	600	雙渦輪增壓	quattro	雙A臂	雙A臂	汽油	48V主動防傾桿	2025-09-16 01:08:47.853462
97	48	95	A3 1.8T	2004	2012	EA113	1781	160	渦輪增壓	FWD	麥花臣	四連桿	汽油	橫置引擎	2025-09-16 01:08:47.856444
98	48	96	A3 40 TFSI	2012	2020	EA888	1984	190	渦輪增壓	quattro	麥花臣	四連桿	汽油	全數位儀表	2025-09-16 01:08:47.859569
99	48	97	A3 35 TFSI	2020	2025	EA211 Evo	1498	150	渦輪增壓	FWD	麥花臣	扭力樑	汽油	MMI觸控系統	2025-09-16 01:08:47.862418
100	49	98	Q3 2.0TFSI	2011	2018	EA888	1984	170	渦輪增壓	quattro	麥花臣	四連桿	汽油	越野模式	2025-09-16 01:08:47.866465
101	49	99	Q3 45 TFSI	2018	2025	EA888	1984	230	渦輪增壓	quattro	麥花臣	四連桿	汽油	虛擬座艙Plus	2025-09-16 01:08:47.869806
102	50	100	R8 4.2 FSI	2007	2015	BHK	4163	420	自然進氣	quattro	雙A臂	雙A臂	汽油	ASF全鋁車身	2025-09-16 01:08:47.872704
103	50	101	R8 V10 Plus	2015	2023	EA824	5204	610	自然進氣	quattro	雙A臂	雙A臂	汽油	全碳纖維車體	2025-09-16 01:08:47.875544
104	51	102	e-tron S	2020	2025	電動	\N	435	電動	quattro	雙A臂	多連桿	純電	三馬達系統	2025-09-16 01:08:47.878881
105	52	103	Q8 55 TFSI	2018	2025	EA839	2995	340	渦輪增壓	quattro	雙A臂	雙A臂	汽油	主動四輪轉向	2025-09-16 01:08:47.883314
106	53	104	Q4 40 e-tron	2021	2025	電動	\N	204	電動	RWD	麥花臣	多連桿	純電	82kWh電池	2025-09-16 01:08:47.886364
107	54	105	A5 2.0TFSI	2007	2016	EA888	1984	180	渦輪增壓	quattro	五連桿	梯型多連桿	汽油	無框車門	2025-09-16 01:08:47.889187
108	54	106	A5 Sportback 45 TFSI	2016	2023	EA888	1984	249	渦輪增壓	quattro	五連桿	五連桿	汽油	矩陣式LED	2025-09-16 01:08:47.892166
109	55	107	RS Q8	2020	2025	EA825	3996	600	雙渦輪增壓	quattro	雙A臂	雙A臂	汽油	主動氣壓懸吊	2025-09-16 01:08:47.895365
110	56	108	Golf 1.6	2004	2009	EA111	1595	102	自然進氣	FWD	麥花臣	扭力樑	汽油	-	2025-09-16 01:08:47.899807
111	56	108	GTI 2.0T	2006	2009	EA113	1984	200	渦輪增壓	FWD	麥花臣	多連桿	汽油	渦輪增壓	2025-09-16 01:08:47.902665
112	56	110	Golf 1.4 TSI	2009	2013	EA111	1390	122	渦輪增壓	FWD	麥花臣	多連桿	汽油	機械+渦輪雙增壓	2025-09-16 01:08:47.90541
113	56	110	GTI 2.0T	2010	2013	EA888	1984	210	渦輪增壓	FWD	麥花臣	多連桿	汽油	XDS電子差速鎖	2025-09-16 01:08:47.90866
114	56	112	Golf 1.4 TSI	2013	2020	EA211	1395	125	渦輪增壓	FWD	麥花臣	多連桿	汽油	ACT汽缸休止	2025-09-16 01:08:47.912855
115	56	112	GTI 2.0T	2014	2020	EA888	1984	230	渦輪增壓	FWD	麥花臣	多連桿	汽油	VAQ電子差速器	2025-09-16 01:08:47.916067
116	56	114	Golf 1.5 eTSI	2020	2025	EA211 EVO	1498	150	渦輪增壓	FWD	麥花臣	多連桿	汽油	48V輕油電	2025-09-16 01:08:47.918748
117	56	114	GTI 2.0T	2021	2025	EA888 Evo4	1984	245	渦輪增壓	FWD	麥花臣	多連桿	汽油	VDM車輛動態管理	2025-09-16 01:08:47.921632
118	57	116	Passat 2.0 TDI	2005	2011	EA189	1968	140	渦輪增壓	FWD	麥花臣	多連桿	柴油	DPF柴油微粒濾清器	2025-09-16 01:08:47.924606
119	57	117	Passat 1.8 TSI	2011	2015	EA888	1798	160	渦輪增壓	FWD	麥花臣	多連桿	汽油	-	2025-09-16 01:08:47.930186
120	57	118	Passat 2.0 TSI	2015	2023	EA888	1984	190	渦輪增壓	FWD	麥花臣	多連桿	汽油	DCC主動懸吊	2025-09-16 01:08:47.934254
121	57	119	Passat 1.5 eTSI	2023	2025	EA211 EVO2	1498	150	渦輪增壓	FWD	麥花臣	多連桿	汽油	插電式混合動力	2025-09-16 01:08:47.938356
122	58	120	Tiguan 2.0 TSI	2008	2016	EA888	1984	180	渦輪增壓	4MOTION	麥花臣	多連桿	汽油	Haldex五代四驅	2025-09-16 01:08:47.941657
123	58	121	Tiguan 330 TSI	2016	2020	EA888	1984	180	渦輪增壓	4MOTION	麥花臣	多連桿	汽油	4MOTION主動控制	2025-09-16 01:08:47.946058
124	58	122	Tiguan 1.5 eTSI	2020	2025	EA211 EVO	1498	150	渦輪增壓	FWD	麥花臣	多連桿	汽油	48V輕油電	2025-09-16 01:08:47.949041
125	59	123	T-Roc 230 TSI	2018	2023	EA211	1395	130	渦輪增壓	FWD	麥花臣	扭力樑	汽油	-	2025-09-16 01:08:47.952111
126	59	123	T-Roc 330 TSI R-Line	2021	2025	EA888	1984	190	渦輪增壓	4MOTION	麥花臣	多連桿	汽油	運動懸吊	2025-09-16 01:08:47.95493
127	60	125	Touran 1.9 TDI	2004	2010	EA188	1896	105	渦輪增壓	FWD	麥花臣	扭力樑	柴油	-	2025-09-16 01:08:47.957981
128	60	126	Touran 1.4 TSI	2010	2015	EA111	1390	140	渦輪增壓	FWD	麥花臣	扭力樑	汽油	-	2025-09-16 01:08:47.962585
129	60	127	Touran 1.5 TSI	2015	2025	EA211	1498	150	渦輪增壓	FWD	麥花臣	多連桿	汽油	ACT汽缸休止	2025-09-16 01:08:47.965417
130	61	128	Arteon 330 TSI	2017	2025	EA888	1984	190	渦輪增壓	4MOTION	麥花臣	多連桿	汽油	DCC主動懸吊	2025-09-16 01:08:47.968411
131	62	129	ID.4 Pro	2021	2025	APP310	0	204	電動	RWD	-	-	純電	77kWh電池組	2025-09-16 01:08:47.971452
132	62	129	ID.4 GTX	2022	2025	APP550 x2	0	299	電動	AWD	-	-	純電	雙馬達四驅	2025-09-16 01:08:47.975942
133	63	131	Caddy 1.6 TDI	2004	2010	EA189	1598	102	渦輪增壓	FWD	麥花臣	葉片彈簧	柴油	-	2025-09-16 01:08:47.97946
134	63	132	Caddy 1.4 TSI	2010	2020	EA211	1395	125	渦輪增壓	FWD	麥花臣	複合式懸吊	汽油	-	2025-09-16 01:08:47.982477
135	63	132	Caddy Cargo	2020	2025	EA288 Evo	1968	122	渦輪增壓	FWD	麥花臣	複合式懸吊	柴油	AdBlue系統	2025-09-16 01:08:47.985238
136	64	134	Polo 1.6	2009	2017	EA111	1598	105	自然進氣	FWD	麥花臣	扭力樑	汽油	-	2025-09-16 01:08:47.988303
137	64	135	Polo 230 TSI	2018	2025	EA211	999	115	渦輪增壓	FWD	麥花臣	扭力樑	汽油	1.0三缸引擎	2025-09-16 01:08:47.992713
138	65	136	Taigo 1.0 TSI	2022	2025	EA211	999	110	渦輪增壓	FWD	麥花臣	扭力樑	汽油	跨界跑旅設計	2025-09-16 01:08:47.996022
139	66	137	ID.3 Pro S	2023	2025	APP310	0	204	電動	RWD	-	-	純電	58kWh電池組	2025-09-16 01:08:47.999579
140	67	138	T-Cross 230 TSI	2019	2025	EA211	999	115	渦輪增壓	FWD	麥花臣	扭力樑	汽油	多功能座椅	2025-09-16 01:08:48.002681
141	68	139	Fabia 1.4 MPI	2005	2007	AUA	1390	80	自然進氣	前置前驅	麥花臣	扭力樑	汽油	ESP電子穩定系統	2025-09-16 01:08:48.006815
142	68	140	1.4L MPI	2007	2014	BZG	1390	75	自然進氣	前置前驅	麥花臣	扭力樑	汽油	電子穩定系統(ESC)	2025-09-16 01:08:48.010459
143	68	140	Fabia Combi 1.2 TSI	2011	2015	CBZB	1197	105	渦輪增壓	前置前驅	麥花臣	扭力樑	汽油	Start-Stop引擎啟停	2025-09-16 01:08:48.013293
144	68	142	Fabia 1.0 TSI	2022	2025	CHPA	999	110	渦輪增壓	前置前驅	麥花臣	多連桿	汽油	Matrix LED頭燈	2025-09-16 01:08:48.01617
145	69	143	Octavia 1.6 MPI	2005	2008	AWL	1598	102	自然進氣	前置前驅	麥花臣	多連桿	汽油	基本安全套件	2025-09-16 01:08:48.019359
146	69	144	1.8 TSI	2008	2013	CZCA	1798	160	渦輪增壓	前置前驅	麥花臣	多連桿	汽油	渦輪增壓直噴引擎，DSG雙離合器	2025-09-16 01:08:48.023598
147	69	145	1.4 TSI	2013	2020	CZEA	1395	150	渦輪增壓	前置前驅	麥花臣	多連桿	汽油	ACT可變氣缸技術，DSG變速箱	2025-09-16 01:08:48.027388
148	69	146	1.5 TSI e-TEC	2019	2024	DJYA	1498	150	渦輪增壓+輕油電	前置前驅	麥花臣	多連桿	汽油+輕油電	Mild Hybrid 48V系統	2025-09-16 01:08:48.030227
149	69	147	1.5 TSI e-TEC	2024	2025	DPCA	1498	150	渦輪增壓+輕油電	前置前驅	麥花臣	多連桿	汽油+輕油電	Superb級內裝升級	2025-09-16 01:08:48.033027
150	69	147	RS 2.0 TSI	2024	2025	DTU	1984	245	渦輪增壓	四輪驅動	麥花臣	多連桿	汽油	性能RS套件，DCC動態底盤控制	2025-09-16 01:08:48.035497
151	70	148	Roomster 1.4 MPI	2006	2010	BBZ	1390	80	自然進氣	前置前驅	麥花臣	扭力樑	汽油	MPV多功能空間設計	2025-09-16 01:08:48.040264
152	71	149	Superb 2.0 FSI	2005	2008	BLR	1984	150	自然進氣	前置前驅	麥花臣	多連桿	汽油	旗艦級舒適座椅	2025-09-16 01:08:48.043945
153	71	150	2.0 TDI	2008	2015	CFGB	1968	170	渦輪增壓柴油	前置前驅	麥花臣	多連桿	柴油	渦輪增壓柴油引擎，DSG雙離合器	2025-09-16 01:08:48.046719
154	71	151	2.0 TSI	2015	2023	CJZA	1984	280	渦輪增壓	前置前驅	麥花臣	多連桿	汽油	渦輪增壓直噴引擎，DSG雙離合器，四輪轉向系統	2025-09-16 01:08:48.049571
155	71	152	2.0 TSI L&K	2023	2025	DTF	1984	280	渦輪增壓	前置前驅	麥花臣	多連桿	汽油	豪華L&K版，Matrix LED	2025-09-16 01:08:48.053788
156	72	153	Yeti 1.2 TSI	2010	2015	CBZB	1197	105	渦輪增壓	前置前驅	麥花臣	多連桿	汽油	跨界SUV設計，VarioRail行李架	2025-09-16 01:08:48.05738
157	73	154	1.6L MPI	2012	2019	CWVA	1598	110	自然進氣	前置前驅	麥花臣	扭力樑	汽油	ESP電子穩定系統	2025-09-16 01:08:48.06088
158	74	155	2.0 TSI	2017	2022	CHHB	1984	180	渦輪增壓	前置四驅	麥花臣	多連桿	汽油	四輪驅動，電子懸吊管理	2025-09-16 01:08:48.064017
159	74	156	2.0 TSI RS	2023	2025	DTF	1984	265	渦輪增壓	四輪驅動	麥花臣	多連桿	汽油	RS性能版，DCC自適應懸吊	2025-09-16 01:08:48.066773
160	75	157	1.5 TSI	2018	2022	CZEA	1498	150	渦輪增壓	前置前驅	麥花臣	多連桿	汽油	渦輪增壓引擎，DSG雙離合器	2025-09-16 01:08:48.071512
161	75	158	1.5 TSI	2022	2025	DPCA	1498	150	渦輪增壓	前置前驅	麥花臣	多連桿	汽油	Simply Clever實用設計	2025-09-16 01:08:48.074207
162	76	159	1.0 TSI	2019	2025	DKRF	999	115	渦輪增壓	前置前驅	麥花臣	多連桿	汽油	城市小型SUV，IQ.DRIVE輔助	2025-09-16 01:08:48.077685
163	77	160	1.0 TSI	2019	2022	CZEA	999	115	渦輪增壓	前置前驅	麥花臣	多連桿	汽油	渦輪增壓，DSG雙離合器	2025-09-16 01:08:48.08066
164	77	161	1.5 TSI	2023	2025	DJYA	1498	150	渦輪增壓+輕油電	前置前驅	麥花臣	多連桿	汽油+輕油電	Mild Hybrid	2025-09-16 01:08:48.08446
165	78	162	Enyaq iV 80	2021	2025	電動	0	204	電動	前置前驅	麥花臣	多連桿	純電	77kWh電池，V2L外放電	2025-09-16 01:08:48.087956
166	78	162	Enyaq Coupe RS	2023	2025	電動	0	299	電動	四輪驅動	麥花臣	多連桿	純電	雙馬達RS版，CCS快充	2025-09-16 01:08:48.090899
167	79	164	Cooper	2005	2006	W11B16A	1598	115	自然吸氣	前輪驅動	麥花臣式	多連桿	汽油	Turbo (S型為渦輪)	2025-09-16 01:08:48.094535
168	79	164	Cooper S	2005	2006	W11B16A	1598	170	渦輪增壓	前輪驅動	麥花臣式	多連桿	汽油	Turbocharged	2025-09-16 01:08:48.097213
169	79	165	Cooper	2007	2013	N12B16A	1598	120	自然吸氣	前輪驅動	麥花臣式	多連桿	汽油	TwinPower Turbo (部分年份)	2025-09-16 01:08:48.101137
170	79	165	Cooper S	2007	2013	N14B16A	1598	175	渦輪增壓	前輪驅動	麥花臣式	多連桿	汽油	雙渦輪增壓技術	2025-09-16 01:08:48.10411
171	80	166	Mini Countryman	2011	2017	N18B16A	1598	240	\N	四輪驅動	多連桿	\N	汽油	\N	2025-09-16 01:08:48.107223
172	79	167	Cooper	2014	2023	B38B15A	1499	136	渦輪增壓	前輪驅動	麥花臣式	多連桿	汽油	TwinPower Turbo	2025-09-16 01:08:48.110394
173	79	167	Cooper S	2014	2023	B48B20A	1998	192	渦輪增壓	前輪驅動	麥花臣式	多連桿	汽油	動態穩定控制系統	2025-09-16 01:08:48.112964
174	81	168	Mini Clubman	2015	2023	B48B20A	1998	280	\N	前輪/四輪驅動	多連桿	\N	汽油	分離式尾門設計	2025-09-16 01:08:48.117392
175	82	169	Mini Convertible	2016	2023	B48B20A	1998	280	\N	前輪驅動	多連桿	\N	汽油	電動軟頂	2025-09-16 01:08:48.120672
176	83	170	Cooper SE	2020	2023	電動	\N	184	純電動	前輪驅動	麥花臣式	多連桿	電動	純電車款	2025-09-16 01:08:48.12364
177	84	171	Carrera	2005	2012	M97.01	3600	345	自然進氣	後置後驅	麥花臣	多連桿	汽油	PASM，PDK雙離合器	2025-09-16 01:08:48.127258
178	84	171	Carrera S	2005	2012	M97.01	3600	385	自然進氣	後置後驅	麥花臣	多連桿	汽油	PASM，PDK雙離合器	2025-09-16 01:08:48.129886
179	84	171	Turbo	2006	2012	M97.70	3600	480	渦輪增壓	後置四驅	麥花臣	多連桿	汽油	雙渦輪增壓，PASM，PDK	2025-09-16 01:08:48.133704
180	84	173	Carrera	2012	2019	MA1.02	3700	370	自然進氣	後置後驅	麥花臣	多連桿	汽油	PASM，PDK	2025-09-16 01:08:48.13648
181	84	173	Carrera 4S	2012	2019	MA1.02	3700	420	自然進氣	後置四驅	麥花臣	多連桿	汽油	PASM，PDK，電子限滑差速器	2025-09-16 01:08:48.139013
182	84	173	GT3	2013	2019	MA1.20	3800	475	自然進氣	後置後驅	麥花臣	多連桿	汽油	賽車化懸吊，輕量化設計	2025-09-16 01:08:48.142065
183	84	175	Carrera	2019	2025	MA2.20	2981	385	雙渦輪增壓	後置後驅	麥花臣	多連桿	汽油	最新PASM，PDK雙離合器	2025-09-16 01:08:48.145256
184	84	175	Turbo S	2020	2025	MA2.20	2981	650	雙渦輪增壓	後置四驅	麥花臣	多連桿	汽油	PDK，PASM，陶瓷碳纖維煞車系統	2025-09-16 01:08:48.149824
185	85	177	Carrera	2005	2012	M97.02	2687	245	自然進氣	中置後驅	雙叉臂	多連桿	汽油	中置引擎，PASM懸吊	2025-09-16 01:08:48.152967
186	85	178	Carrera	2012	2016	MA1.10	2981	265	自然進氣	中置後驅	雙叉臂	多連桿	汽油	PASM，PDK	2025-09-16 01:08:48.155647
187	86	179	Carrera	2005	2012	M97.02	2687	245	自然進氣	中置後驅	雙叉臂	多連桿	汽油	PASM，PDK	2025-09-16 01:08:48.158925
188	86	180	Carrera	2012	2016	MA1.10	2981	265	自然進氣	中置後驅	雙叉臂	多連桿	汽油	PASM，PDK	2025-09-16 01:08:48.162008
189	87	181	3.2L V6	2003	2010	MZ1	3198	250	自然進氣	前置四驅	雙叉臂	多連桿	汽油	PTM四輪驅動系統	2025-09-16 01:08:48.166287
190	87	182	3.6L V6	2010	2017	MA1	3596	300	自然進氣	前置四驅	雙叉臂	多連桿	汽油	PASM，PTM	2025-09-16 01:08:48.169168
191	87	183	3.0L Turbo	2017	2025	MA2	2995	340	渦輪增壓	前置四驅	雙叉臂	多連桿	汽油	PASM，PTM，PDK	2025-09-16 01:08:48.172013
192	88	184	3.0L Turbo	2019	2025	MA2	2995	340	渦輪增壓	前置四驅	雙叉臂	多連桿	汽油	PASM，PTM	2025-09-16 01:08:48.17518
193	89	185	2.0L Turbo	2014	2021	EA888	1984	252	渦輪增壓	前置四驅	麥花臣	多連桿	汽油	PASM，PTM	2025-09-16 01:08:48.180095
194	90	186	4.8L V8	2009	2016	M48.00	4800	400	自然進氣	前置後驅/四驅	雙叉臂	多連桿	汽油	PASM，PDK	2025-09-16 01:08:48.183436
195	90	187	2.9L V6 Twin Turbo	2017	2021	MA2	2894	330	雙渦輪增壓	前置四驅	雙叉臂	多連桿	汽油	PASM，PDK	2025-09-16 01:08:48.186242
196	91	188	Cayman S	2016	2020	MA2.20	2981	350	渦輪增壓	中置後驅	雙叉臂	多連桿	汽油	PASM，PDK	2025-09-16 01:08:48.189169
197	91	188	Boxster S	2016	2020	MA2.20	2981	350	渦輪增壓	中置後驅	雙叉臂	多連桿	汽油	PASM，PDK	2025-09-16 01:08:48.191907
198	92	189	4S	2019	2025	電動馬達	\N	420	電動	四輪驅動	雙叉臂	多連桿	純電	800V電池，PTM，電子懸吊系統	2025-09-16 01:08:48.196759
199	93	190	Focus 2.0	2004	2008	Duratec-HE	1999	145	自然進氣	FWD	麥花臣	多連桿	汽油	反置式引擎	2025-09-16 01:08:48.200677
200	93	191	Focus TDCi	2011	2015	Duratorq TDCi	1560	115	渦輪增壓	FWD	麥花臣	多連桿	柴油	DPF系統	2025-09-16 01:08:48.203535
201	93	192	Focus 1.5T	2015	2018	EcoBoost	1499	180	渦輪增壓	FWD	麥花臣	扭力樑	汽油	缸內直噴	2025-09-16 01:08:48.20627
202	93	193	Focus ST-Line	2018	2022	EcoBoost	1499	182	渦輪增壓	FWD	麥花臣	多連桿	汽油	Co-Pilot360	2025-09-16 01:08:48.210662
203	93	194	Focus ST	2022	2025	EcoBoost	1999	280	渦輪增壓	FWD	麥花臣	多連桿	汽油	電子限滑差速器	2025-09-16 01:08:48.214042
204	94	195	Kuga 2.0T	2013	2016	EcoBoost	1999	242	渦輪增壓	AWD	麥花臣	多連桿	汽油	智慧型四驅	2025-09-16 01:08:48.217017
205	94	196	Kuga 180	2020	2025	EcoBoost	1499	180	渦輪增壓	FWD	麥花臣	多連桿	汽油	輕量化車體	2025-09-16 01:08:48.219798
206	94	196	Kuga ST-Line	2020	2025	EcoBoost	1999	250	渦輪增壓	AWD	麥花臣	多連桿	汽油	運動化懸吊	2025-09-16 01:08:48.222508
207	95	197	Mondeo 2.0T	2007	2014	Duratec-HE	1999	203	渦輪增壓	FWD	麥花臣	多連桿	汽油	歐規底盤	2025-09-16 01:08:48.226931
208	95	198	Mondeo Hybrid	2015	2022	Atkinson	1999	187	阿特金森循環	FWD	麥花臣	多連桿	油電混合	鋰電池組	2025-09-16 01:08:48.230218
209	95	199	Mondeo Wagon	2023	2025	EcoBoost	1999	253	渦輪增壓	FWD	麥花臣	多連桿	汽油	歐洲進口	2025-09-16 01:08:48.233005
210	96	200	Fiesta 1.6	2008	2013	Duratec	1596	120	自然進氣	FWD	麥花臣	扭力樑	汽油	歐洲設計	2025-09-16 01:08:48.236061
211	96	201	Fiesta 1.0T	2014	2022	EcoBoost	999	125	渦輪增壓	FWD	麥花臣	扭力樑	汽油	三缸引擎	2025-09-16 01:08:48.23907
212	97	202	Ranger 3.2	2012	2019	Duratorq	3198	200	渦輪增壓	4WD	雙A臂	葉片彈簧	柴油	電子加力箱	2025-09-16 01:08:48.24382
213	97	203	Ranger Wildtrak	2019	2025	EcoBlue	1997	213	渦輪增壓	4WD	雙A臂	葉片彈簧	柴油	地形管理系統	2025-09-16 01:08:48.246747
214	98	204	Tourneo Custom	2014	2023	Duratorq	2198	130	渦輪增壓	FWD	麥花臣	葉片彈簧	柴油	商旅設定	2025-09-16 01:08:48.249785
215	99	205	Tourneo Connect	2022	2025	EcoBoost	1499	125	渦輪增壓	FWD	麥花臣	扭力樑	汽油	5+2人座	2025-09-16 01:08:48.252782
216	100	206	Mustang 2.3T	2015	2023	EcoBoost	2261	290	渦輪增壓	RWD	麥花臣	多連桿	汽油	運動化懸吊	2025-09-16 01:08:48.255729
217	100	207	Mustang Dark Horse	2024	2025	Coyote	5038	500	自然進氣	RWD	麥花臣	多連桿	汽油	賽道調校	2025-09-16 01:08:48.261331
218	101	208	Escape 2.3	2004	2008	Duratec	2261	153	自然進氣	4WD	麥花臣	雙連桿	汽油	適時四驅	2025-09-16 01:08:48.264602
219	102	209	EcoSport 1.5	2014	2022	Dragon	1498	112	自然進氣	FWD	麥花臣	扭力樑	汽油	都會SUV	2025-09-16 01:08:48.267654
220	103	210	Kuga PHEV	2022	2025	EcoBoost PHEV	1499	225	渦輪增壓	FWD	麥花臣	多連桿	插電混動	14.4kWh電池	2025-09-16 01:08:48.270664
221	104	211	Focus Active	2022	2025	EcoBoost	1499	182	渦輪增壓	FWD	麥花臣	多連桿	汽油	跨界加高	2025-09-16 01:08:48.275012
222	105	212	Explorer	2023	2025	EcoBoost	2997	365	渦輪增壓	4WD	雙A臂	多連桿	汽油	後驅平台	2025-09-16 01:08:48.278743
223	106	213	S40 2.0L T4	2004	2012	B4204T11	1984	145	渦輪增壓	前置前驅	麥花臣	多連桿	汽油	Drive-E引擎，ESC	2025-09-16 01:08:48.282002
224	106	213	S40 2.5T	2004	2012	B5254T7	2521	230	渦輪增壓	前置前驅	麥花臣	多連桿	汽油	Turbo高性能版	2025-09-16 01:08:48.284538
225	107	214	S60 2.4L	2000	2009	B5244S	2435	140	自然進氣	前置前驅/四驅	麥花臣	多連桿	汽油	\N	2025-09-16 01:08:48.2879
226	107	215	S60 T5	2010	2018	B4204T27	1969	245	渦輪增壓	前置前驅/四驅	雙叉臂	多連桿	汽油	Drive-E	2025-09-16 01:08:48.291875
227	107	215	S60 T6	2010	2018	B6304T37	2953	304	渦輪增壓	前置四驅	雙叉臂	多連桿	汽油	Polestar	2025-09-16 01:08:48.2947
228	107	216	S60 T8 Polestar	2019	2025	B4204T43	1969	415	渦輪增壓+機械增壓+電動	四輪驅動	雙叉臂	多連桿	油電混合	Polestar Engineered	2025-09-16 01:08:48.297659
229	107	216	S60 B5	2019	2025	B4204T28	1969	250	渦輪增壓+48V輕油電	前輪驅動/四輪驅動	雙叉臂	多連桿	汽油	48V輕油電系統，Pilot Assist	2025-09-16 01:08:48.300266
230	108	217	S80 3.2	2006	2016	B6324S	3192	238	自然進氣	前置前驅	麥花臣	多連桿	汽油	\N	2025-09-16 01:08:48.304772
231	108	217	S80 T6	2006	2016	B6304T	2953	285	渦輪增壓	四輪驅動	麥花臣	多連桿	汽油	AWD系統	2025-09-16 01:08:48.30765
232	109	218	S90 B5	2016	2025	B4204T28	1969	250	渦輪增壓+48V輕油電	四輪驅動	雙叉臂	多連桿	汽油	48V輕油電系統，Pilot Assist	2025-09-16 01:08:48.311262
233	110	219	V50 2.4i	2004	2012	B5244S5	2435	170	自然進氣	前置前驅	麥花臣	多連桿	汽油	\N	2025-09-16 01:08:48.314212
234	111	220	V60 T5	2010	2018	B4204T7	1999	240	渦輪增壓	前置前驅	麥花臣	多連桿	汽油	Drive-E	2025-09-16 01:08:48.317069
235	111	221	V60 B5	2019	2025	B4204T28	1969	250	渦輪增壓+48V輕油電	前輪驅動/四輪驅動	雙叉臂	多連桿	汽油	48V輕油電系統，Pilot Assist	2025-09-16 01:08:48.321259
236	112	222	V70 2.5T	2000	2007	B5254T2	2521	210	渦輪增壓	前置前驅/四驅	麥花臣	多連桿	汽油	\N	2025-09-16 01:08:48.324621
237	113	223	XC60 3.0 T6	2008	2017	B6304T43	2953	304	渦輪增壓	四輪驅動	麥花臣	多連桿	汽油	AWD系統	2025-09-16 01:08:48.328069
238	113	224	XC60 B4	2019	2025	B4204T5	1969	197	渦輪增壓+48V輕油電	前輪驅動	雙A臂	多連桿	汽油	48V輕油電系統，Pilot Assist	2025-09-16 01:08:48.330891
239	113	224	XC60 B5	2019	2025	B4204T28	1969	250	渦輪增壓+48V輕油電	四輪驅動	雙A臂	多連桿	汽油	48V輕油電系統，Pilot Assist	2025-09-16 01:08:48.333424
240	113	224	XC60 T8 Recharge	2017	2025	B4204T48	1969	400	渦輪增壓+電動	四輪驅動	雙A臂	多連桿	油電混合	插電混合動力，Pilot Assist	2025-09-16 01:08:48.337702
241	114	226	XC70 3.2	2007	2016	B6324S	3192	238	自然進氣	四輪驅動	麥花臣	多連桿	汽油	AWD系統	2025-09-16 01:08:48.340771
242	115	227	XC90 2.5T	2002	2014	B5254T2	2521	210	渦輪增壓	前置前驅/四驅	麥花臣	多連桿	汽油	\N	2025-09-16 01:08:48.344222
243	115	228	XC90 T8 Recharge	2015	2025	B4204T48	1969	400	渦輪增壓+電動	四輪驅動	雙A臂	多連桿	油電混合	插電混合動力，Pilot Assist	2025-09-16 01:08:48.346919
244	116	229	XC40 B4	2018	2025	B420T5	1969	197	渦輪增壓	前置前驅	麥花臣	多連桿	汽油	Mild Hybrid	2025-09-16 01:08:48.350991
245	116	229	XC40 Recharge	2021	2025	電動	\N	408	電動	四輪驅動	麥花臣	多連桿	純電	雙電動馬達，78kWh電池	2025-09-16 01:08:48.354238
246	117	231	C30 2.4i	2006	2013	B5244S4	2435	170	自然進氣	前置前驅	麥花臣	多連桿	汽油	\N	2025-09-16 01:08:48.357323
247	118	232	C70 T5	2006	2013	B5244T7	2521	230	渦輪增壓	前置前驅	麥花臣	多連桿	汽油	硬頂敞篷	2025-09-16 01:08:48.360834
248	119	233	Toyota 86 標準版	2012	2020	FA20	1998	200	自然進氣	後輪驅動	雙叉臂	雙叉臂	汽油	水平對臥引擎，輕量化車身，運動化懸吊，TRD套件（部分車型）	2025-09-16 01:08:48.364063
249	119	233	Toyota 86 GT	2012	2020	FA20	1998	200	自然進氣	後輪驅動	雙叉臂	雙叉臂	汽油	運動化懸吊，電子穩定控制，增強煞車系統	2025-09-16 01:08:48.368123
250	119	234	Toyota 86 改款版	2020	2025	FA24	2362	235	自然進氣	後輪驅動	雙叉臂	雙叉臂	汽油	改良FA24引擎，增強懸吊系統，安全輔助系統	2025-09-16 01:08:48.371207
251	120	235	Altis 1.8J	2004	2007	1ZZ-FE	1794	132	自然進氣	FWD	麥花臣	扭力桿	汽油	VVT-i	2025-09-16 01:08:48.374128
252	120	236	Altis 1.8E	2008	2013	2ZR-FE	1798	140	自然進氣	FWD	麥花臣	扭力桿	汽油	Dual VVT-i	2025-09-16 01:08:48.377302
253	120	237	Altis 1.8尊爵	2014	2019	2ZR-FE	1798	140	自然進氣	FWD	麥花臣	扭力桿	汽油	Super CVT-i	2025-09-16 01:08:48.380244
254	120	238	Altis 1.8油電	2019	2023	2ZR-FXE	1798	122	阿特金森循環	FWD	麥花臣	雙A臂	油電混合	THS II	2025-09-16 01:08:48.384424
255	120	238	Altis GR Sport	2021	2025	M15A-FKS	1490	140	渦輪增壓	FWD	麥花臣	雙A臂	汽油	1.5三缸	2025-09-16 01:08:48.387247
256	121	240	Camry 2.0G	2006	2011	1AZ-FE	1998	147	自然進氣	FWD	麥花臣	雙連桿	汽油	VVT-i	2025-09-16 01:08:48.390346
257	121	241	Camry 2.5Q	2012	2017	2AR-FE	2494	181	自然進氣	FWD	麥花臣	雙連桿	汽油	Dual VVT-i	2025-09-16 01:08:48.393575
258	121	242	Camry 2.5 Hybrid	2018	2023	A25A-FXS	2487	178	阿特金森循環	FWD	麥花臣	雙A臂	油電混合	THS II	2025-09-16 01:08:48.39888
259	121	243	Camry 2.5油電旗艦	2023	2025	A25A-FXS	2487	222	阿特金森循環	FWD	麥花臣	雙A臂	油電混合	新THS	2025-09-16 01:08:48.402573
260	122	244	RAV4 2.4G	2006	2012	2AZ-FE	2362	170	自然進氣	4WD	麥花臣	雙連桿	汽油	VVT-i	2025-09-16 01:08:48.405813
261	122	245	RAV4 2.5 4WD	2013	2018	2AR-FE	2494	180	自然進氣	4WD	麥花臣	雙連桿	汽油	Valvematic	2025-09-16 01:08:48.409174
262	122	246	RAV4 2.5 Adventure	2019	2025	A25A-FKS	2487	207	自然進氣	4WD	麥花臣	雙A臂	汽油	Dynamic Force	2025-09-16 01:08:48.413363
263	122	246	RAV4 Hybrid	2019	2025	A25A-FXS	2487	222	阿特金森循環	E-Four	麥花臣	雙A臂	油電混合	E-Four四驅	2025-09-16 01:08:48.417162
264	123	247	Yaris 1.5G	2006	2014	1NZ-FE	1497	109	自然進氣	FWD	麥花臣	扭力桿	汽油	VVT-i	2025-09-16 01:08:48.42098
265	123	248	Yaris 1.5豪華	2014	2020	1NZ-FE	1497	109	自然進氣	FWD	麥花臣	扭力桿	汽油	Super CVT-i	2025-09-16 01:08:48.424033
266	123	249	Yaris GR Sport	2020	2025	M15A-FKS	1490	107	渦輪增壓	FWD	麥花臣	扭力桿	汽油	1.5三缸	2025-09-16 01:08:48.428035
267	124	250	Vios 1.5E	2003	2007	1NZ-FE	1497	109	自然進氣	FWD	麥花臣	扭力桿	汽油	VVT-i	2025-09-16 01:08:48.431546
268	124	251	Vios 1.5雅緻	2008	2013	1NZ-FE	1497	109	自然進氣	FWD	麥花臣	扭力桿	汽油	Dual VVT-i	2025-09-16 01:08:48.43442
269	124	252	Vios 1.5豪華	2014	2023	2NR-FE	1496	107	自然進氣	FWD	麥花臣	扭力桿	汽油	Super CVT-i	2025-09-16 01:08:48.437264
270	124	253	Vios 1.5油電	2023	2025	M15A-FXE	1490	116	阿特金森循環	FWD	麥花臣	扭力桿	油電混合	新THS	2025-09-16 01:08:48.440278
271	125	254	Prius 1.8	2009	2015	2ZR-FXE	1798	136	阿特金森循環	FWD	麥花臣	扭力桿	油電混合	THS II	2025-09-16 01:08:48.445407
272	125	255	Prius 1.8	2016	2022	2ZR-FXE	1798	122	阿特金森循環	FWD	麥花臣	雙A臂	油電混合	THS III	2025-09-16 01:08:48.448253
273	125	256	Prius PHEV	2023	2025	A25A-FXS	2487	223	阿特金森循環	FWD	麥花臣	雙A臂	插電混動	13.6kWh電池	2025-09-16 01:08:48.451141
274	126	257	Alphard 3.5	2009	2015	2GR-FE	3456	275	自然進氣	FWD	麥花臣	雙連桿	汽油	Dual VVT-i	2025-09-16 01:08:48.454347
275	126	258	Alphard 2.5油電	2015	2023	2AR-FXE	2494	152	阿特金森循環	4WD	麥花臣	雙連桿	油電混合	E-Four	2025-09-16 01:08:48.457154
276	126	259	Alphard 2.5油電	2023	2025	A25A-FXS	2487	190	阿特金森循環	4WD	麥花臣	雙連桿	油電混合	新THS	2025-09-16 01:08:48.462417
277	127	260	Sienta 1.8	2016	2022	2ZR-FE	1798	140	自然進氣	FWD	麥花臣	扭力桿	汽油	Super CVT-i	2025-09-16 01:08:48.465562
278	127	261	Sienta 1.8油電	2022	2025	M18A-FXE	1798	140	阿特金森循環	FWD	麥花臣	扭力桿	油電混合	新THS	2025-09-16 01:08:48.468393
279	128	262	Corolla Cross油電	2020	2025	M20A-FXS	1987	145	阿特金森循環	E-Four	麥花臣	扭力桿	油電混合	E-Four	2025-09-16 01:08:48.471569
280	128	262	Corolla Cross GR Sport	2023	2025	M20A-FKS	1987	170	自然進氣	FWD	麥花臣	扭力桿	汽油	2.0 Dynamic Force	2025-09-16 01:08:48.476037
281	129	264	Crown Crossover	2023	2025	A25A-FXS	2487	234	阿特金森循環	E-Four	麥花臣	多連桿	油電混合	Direct4四驅	2025-09-16 01:08:48.479094
282	130	265	Hilux 2.8	2019	2025	1GD-FTV	2755	204	渦輪增壓	4WD	雙A臂	葉片彈簧	柴油	DPF+SCR	2025-09-16 01:08:48.482061
283	131	266	Granvia 2.8	2019	2025	1GD-FTV	2755	176	渦輪增壓	RWD	麥花臣	葉片彈簧	柴油	9人座設定	2025-09-16 01:08:48.485053
284	132	267	bZ4X	2022	2025	電動	\N	218	電動	AWD	麥花臣	雙A臂	純電	71.4kWh電池	2025-09-16 01:08:48.488182
285	133	268	C-HR 1.8油電	2017	2023	2ZR-FXE	1798	122	阿特金森循環	FWD	麥花臣	雙A臂	油電混合	THS II	2025-09-16 01:08:48.493108
286	134	269	Yaris Cross油電	2023	2025	M15A-FXE	1490	116	阿特金森循環	FWD	麥花臣	扭力桿	油電混合	新THS	2025-09-16 01:08:48.496092
287	135	270	Civic 1.8	2006	2011	R18A1	1799	140	自然進氣	前置前驅	麥弗遜	扭力梁	汽油	SOHC i-VTEC	2025-09-16 01:08:48.499281
288	135	271	Civic 2.0 Type S	2006	2011	K20Z3	1998	200	自然進氣	前置前驅	麥弗遜	扭力梁	汽油	DOHC i-VTEC	2025-09-16 01:08:48.502146
289	135	272	Civic 1.8	2012	2016	R18Z1	1798	141	自然進氣	前置前驅	麥弗遜	扭力梁	汽油	SOHC i-VTEC	2025-09-16 01:08:48.507928
290	135	273	Civic 2.0	2012	2016	K20Z3	1998	155	自然進氣	前置前驅	麥弗遜	扭力梁	汽油	DOHC i-VTEC	2025-09-16 01:08:48.511595
291	135	274	Civic 1.5 Turbo	2016	2021	L15B7	1498	174	渦輪增壓	前置前驅	麥弗遜	多連桿	汽油	DOHC VTEC Turbo	2025-09-16 01:08:48.514475
292	135	274	Civic Type R	2017	2021	K20C1	1996	306	渦輪增壓	前置前驅	麥弗遜	多連桿	汽油	DOHC VTEC Turbo	2025-09-16 01:08:48.517302
293	135	276	Civic e:HEV	2022	2025	LFA1	1993	184	阿特金森循環+電動	前置前驅	麥弗遜	多連桿	油電混合	e:HEV油電系統	2025-09-16 01:08:48.521426
294	135	276	Civic Type R	2023	2025	K20C1	1996	315	渦輪增壓	前置前驅	麥弗遜	多連桿	汽油	DOHC VTEC Turbo	2025-09-16 01:08:48.524869
295	136	278	Accord 2.4	2003	2008	K24A4	2354	190	自然進氣	前置前驅	雙A臂	多連桿	汽油	DOHC i-VTEC	2025-09-16 01:08:48.528112
296	136	279	Accord 2.4	2008	2013	K24Z2	2354	180	自然進氣	前置前驅	雙A臂	多連桿	汽油	DOHC i-VTEC	2025-09-16 01:08:48.530762
297	136	280	Accord 3.5	2008	2013	J35Z2	3471	271	自然進氣	前置前驅	雙A臂	多連桿	汽油	DOHC VTEC V6	2025-09-16 01:08:48.533469
298	136	281	Accord 2.4	2013	2019	K24W1	2356	188	自然進氣	前置前驅	麥弗遜	多連桿	汽油	DOHC i-VTEC	2025-09-16 01:08:48.537328
299	136	281	Accord 3.5	2013	2019	J35Y1	3471	276	自然進氣	前置前驅	麥弗遜	多連桿	汽油	DOHC VTEC V6	2025-09-16 01:08:48.540322
300	136	282	Accord 1.5 Turbo	2018	2025	L15BE	1498	192	渦輪增壓	前置前驅	麥弗遜	多連桿	汽油	DOHC VTEC Turbo	2025-09-16 01:08:48.543646
301	136	282	Accord 2.0 Hybrid	2018	2025	LFA1	1993	212	阿特金森循環+電動	前置前驅	麥弗遜	多連桿	油電混合	e:HEV油電系統	2025-09-16 01:08:48.546219
302	137	283	CR-V 2.4	2007	2011	K24Z1	2354	170	自然進氣	前置四驅	麥弗遜	多連桿	汽油	Real Time 4WD	2025-09-16 01:08:48.549298
303	137	284	CR-V 2.4	2012	2016	R24A1	2354	190	自然進氣	前置四驅	麥弗遜	多連桿	汽油	Real Time AWD	2025-09-16 01:08:48.553569
304	137	285	CR-V 1.5 Turbo	2017	2022	L15BE	1498	193	渦輪增壓	前置四驅	麥弗遜	多連桿	汽油	Real Time AWD	2025-09-16 01:08:48.556552
305	137	286	CR-V e:HEV	2023	2025	LFA1	1993	204	阿特金森循環+電動	前置四驅	麥弗遜	多連桿	油電混合	e:HEV油電系統	2025-09-16 01:08:48.559631
306	138	287	Fit 1.5	2008	2014	L15A7	1497	120	自然進氣	前置前驅	麥弗遜	扭力梁	汽油	SOHC i-VTEC	2025-09-16 01:08:48.562862
307	138	288	Fit 1.5	2014	2020	L15B1	1497	130	自然進氣	前置前驅	麥弗遜	扭力梁	汽油	DOHC i-VTEC	2025-09-16 01:08:48.565644
308	138	289	Fit e:HEV	2020	2025	LFA1	1498	123	阿特金森循環+電動	前置前驅	麥弗遜	扭力梁	油電混合	e:HEV油電系統	2025-09-16 01:08:48.569868
309	139	290	HR-V 1.8	2015	2021	L18A	1799	143	自然進氣	前置前驅	麥弗遜	扭力梁	汽油	SOHC i-VTEC	2025-09-16 01:08:48.572901
310	139	291	HR-V e:HEV	2022	2025	L15ZF	1498	131	自然進氣	前置前驅	麥弗遜	扭力梁	汽油	DOHC i-VTEC	2025-09-16 01:08:48.576014
311	139	291	HR-V 1.5 Turbo	2022	2025	L15C	1498	177	渦輪增壓	前置前驅	麥弗遜	扭力梁	汽油	VTEC Turbo	2025-09-16 01:08:48.578634
312	140	292	Odyssey 2.4	2004	2013	K24A	2354	160	自然進氣	前置前驅	麥弗遜	扭力梁	汽油	DOHC i-VTEC	2025-09-16 01:08:48.581856
313	140	293	Odyssey 2.4	2014	2020	K24W	2354	175	自然進氣	前置前驅	麥弗遜	扭力梁	汽油	DOHC i-VTEC	2025-09-16 01:08:48.58674
314	140	294	Odyssey e:HEV	2021	2025	LFA1	1993	215	阿特金森循環+電動	前置前驅	麥弗遜	扭力梁	油電混合	e:HEV油電系統	2025-09-16 01:08:48.589664
315	141	295	City 1.5	2008	2014	L15A7	1497	120	自然進氣	前置前驅	麥弗遜	扭力梁	汽油	SOHC i-VTEC	2025-09-16 01:08:48.593088
316	141	296	City 1.5	2014	2020	L15B	1497	121	自然進氣	前置前驅	麥弗遜	扭力梁	汽油	DOHC i-VTEC	2025-09-16 01:08:48.595929
317	141	297	City e:HEV	2020	2025	LFA1	1498	126	阿特金森循環+電動	前置前驅	麥弗遜	扭力梁	油電混合	e:HEV油電系統	2025-09-16 01:08:48.599595
318	142	298	S2000	2005	2009	F22C	2157	237	自然進氣	後置後驅	雙A臂	雙A臂	汽油	DOHC VTEC	2025-09-16 01:08:48.602867
319	143	299	Legend 3.5	2005	2012	J35A	3471	295	自然進氣	前置四驅	雙A臂	多連桿	汽油	SH-AWD	2025-09-16 01:08:48.605752
320	144	300	Pilot 3.5	2005	2008	J35A9	3471	244	自然進氣	前置四驅	麥弗遜	多連桿	汽油	VTM-4 AWD	2025-09-16 01:08:48.60889
321	144	301	Pilot 3.5	2009	2015	J35Z4	3471	250	自然進氣	前置四驅	麥弗遜	多連桿	汽油	VTM-4 AWD	2025-09-16 01:08:48.612051
322	144	302	Pilot 3.5	2016	2022	J35Y6	3471	280	自然進氣	前置四驅	麥弗遜	多連桿	汽油	i-VTM4 AWD	2025-09-16 01:08:48.616132
323	144	303	Pilot 3.5	2023	2025	J35Y7	3471	285	自然進氣	前置四驅	麥弗遜	多連桿	汽油	i-VTM4 AWD	2025-09-16 01:08:48.619176
324	145	304	Element 2.4	2005	2011	K24A4	2354	156	自然進氣	前置四驅	麥弗遜	多連桿	汽油	Real Time 4WD	2025-09-16 01:08:48.622187
325	146	305	G35	2003	2006	VQ35DE	3498	280	自然進氣	RWD/4WD	雙A臂	多連桿	汽油	VVEL、主動式轉向系統	2025-09-16 01:08:48.625321
326	147	306	G37	2007	2013	VQ37VHR	3696	330	自然進氣	RWD/4WD	雙A臂	多連桿	汽油	VVEL、主動式轉向系統	2025-09-16 01:08:48.628389
327	148	307	Q50	2013	2018	2.0T/3.5L VQ35HR/VQ37VHR	\N	\N	渦輪增壓/自然進氣	RWD/AWD	雙A臂	多連桿	汽油	Direct Adaptive Steering	2025-09-16 01:08:48.632611
328	148	308	Q50	2019	2023	V6 3.0T VR30DDTT	2997	\N	雙渦輪增壓	RWD/AWD	雙A臂	多連桿	汽油	VC-Turbo可變壓縮比引擎	2025-09-16 01:08:48.635577
329	149	309	QX50	2008	2017	VQ35HR	3498	325	自然進氣	RWD/AWD	雙A臂	多連桿	汽油	全時四驅系統	2025-09-16 01:08:48.638496
330	149	310	QX50	2018	2025	VC-Turbo VR30DDTT	2997	268	可變壓縮比渦輪增壓	RWD/AWD	麥花臣	多連桿	汽油	VC-Turbo、ProPILOT駕駛輔助	2025-09-16 01:08:48.641372
331	150	311	QX60	2013	2020	VQ35DE	3498	265	自然進氣	FWD/AWD	麥花臣	多連桿	汽油	豪華座艙科技	2025-09-16 01:08:48.644718
332	150	312	QX60	2021	2025	VQ35DE	3498	295	自然進氣	FWD/AWD	麥花臣	多連桿	汽油	ProPILOT智能駕駛輔助	2025-09-16 01:08:48.648517
333	151	313	FX35	2003	2008	VQ35DE	3498	280	自然進氣	RWD/AWD	雙A臂	多連桿	汽油	主動懸吊系統	2025-09-16 01:08:48.651514
334	152	314	FX37	2009	2012	VQ37VHR	3696	325	自然進氣	RWD/AWD	雙A臂	多連桿	汽油	主動懸吊系統	2025-09-16 01:08:48.6544
335	153	315	FX50	2009	2013	VQ50VHR	5000	390	自然進氣	RWD/AWD	雙A臂	多連桿	汽油	主動懸吊系統	2025-09-16 01:08:48.65811
336	154	316	Q70	2014	2019	VQ37VHR/VR30DDTT	\N	\N	自然進氣/渦輪增壓	RWD/AWD	雙A臂	多連桿	汽油	Direct Adaptive Steering	2025-09-16 01:08:48.66229
337	155	317	IS250	2006	2013	4GR-FSE	2499	204	自然進氣	RWD	雙A臂	多連桿	汽油	VVT-i、直噴	2025-09-16 01:08:48.666037
338	155	318	IS300	2013	2020	8AR-FTS	2494	245	渦輪增壓	RWD/四驅	雙A臂	多連桿	汽油	渦輪增壓、直噴	2025-09-16 01:08:48.668817
339	156	319	ES350	2006	2012	2GR-FE	3456	275	自然進氣	FWD	麥花臣	多連桿	汽油	VVT-i	2025-09-16 01:08:48.671717
340	156	320	ES300h	2012	2018	2AR-FXE+電動	2494	200	自然進氣＋電動	FWD	麥花臣	多連桿	油電混合	VVT-i、Hybrid Synergy Drive	2025-09-16 01:08:48.674379
341	157	321	RX350	2008	2015	2GR-FE	3456	270	自然進氣	四驅	雙A臂	多連桿	汽油	VVT-i	2025-09-16 01:08:48.679299
342	157	322	RX450h	2015	2022	2GR-FXE+電動	3456	308	自然進氣＋電動	四驅	雙A臂	多連桿	油電混合	混合動力系統	2025-09-16 01:08:48.682129
343	158	323	LS460	2006	2017	UR-Series V8	4608	385	自然進氣	RWD	雙A臂	多連桿	汽油	VVT-i、氣缸停用	2025-09-16 01:08:48.684995
344	158	324	LS500h	2017	2023	2UR-FXE+電動	3456	354	自然進氣＋電動	四驅	雙A臂	多連桿	油電混合	Lexus Multi Stage Hybrid	2025-09-16 01:08:48.68786
345	159	325	NX300h	2014	2021	2AR-FXE+電動	2494	194	自然進氣＋電動	前驅/四驅	麥花臣	多連桿	油電混合	Hybrid Synergy Drive	2025-09-16 01:08:48.691021
346	159	326	NX350	2021	2025	T24A-FTS	2487	279	渦輪增壓	前驅/四驅	麥花臣	多連桿	汽油	渦輪增壓、直噴	2025-09-16 01:08:48.6955
347	160	327	UX200	2018	2025	M20A-FKS	1987	171	自然進氣	前驅	麥花臣	多連桿	汽油	VVT-i	2025-09-16 01:08:48.698396
348	160	327	UX250h	2018	2025	2ZR-FXE+電動	1798	184	自然進氣＋電動	前驅	多連桿	\N	Hybrid Synergy Drive	\N	2025-09-16 01:08:48.700937
349	161	328	LC500	2017	2025	2UR-GSE	4969	471	自然進氣	RWD	雙A臂	多連桿	汽油	V8自然進氣	2025-09-16 01:08:48.704049
350	161	328	LC500h	2017	2025	2UR-GSE+電動	3456	359	自然進氣＋電動	RWD	雙A臂	多連桿	油電混合	多階段混合動力	2025-09-16 01:08:48.706848
351	162	329	Mazda3	2013	2019	Skyactiv-G 2.0	1998	155	自然進氣	FWD	麥花臣	多連桿	汽油	Skyactiv技術	2025-09-16 01:08:48.711566
352	163	330	Mazda3	2019	2023	Skyactiv-G 2.0	1998	162	自然進氣	FWD/四驅	麥花臣	多連桿	汽油	Skyactiv-X 壓燃引擎	2025-09-16 01:08:48.714445
353	164	331	Mazda6	2012	2018	Skyactiv-G 2.5	2488	190	自然進氣	FWD	雙A臂	多連桿	汽油	Skyactiv技術	2025-09-16 01:08:48.717369
354	165	332	Mazda6	2018	2023	Skyactiv-G 2.5	2488	194	自然進氣	FWD/四驅	雙A臂	多連桿	汽油	Skyactiv技術	2025-09-16 01:08:48.720365
355	166	333	CX-5	2012	2017	Skyactiv-G 2.0	1998	155	自然進氣	四驅	麥花臣	多連桿	汽油	Skyactiv技術	2025-09-16 01:08:48.72462
356	167	334	CX-5	2017	2023	Skyactiv-G 2.5	2488	190	自然進氣	四驅	麥花臣	多連桿	汽油	Skyactiv技術	2025-09-16 01:08:48.728221
357	168	335	CX-30	2019	2023	Skyactiv-G 2.0	1998	156	自然進氣	四驅	麥花臣	多連桿	汽油	Skyactiv技術	2025-09-16 01:08:48.731233
358	169	336	CX-3	2015	2020	Skyactiv-G 2.0	1998	148	自然進氣	四驅	麥花臣	多連桿	汽油	Skyactiv技術	2025-09-16 01:08:48.734204
359	170	337	MX-5	2015	2023	Skyactiv-G 2.0	1998	184	自然進氣	RWD	雙A臂	多連桿	汽油	Skyactiv技術	2025-09-16 01:08:48.737041
360	171	338	Tiida	2005	2011	MR16DE	1598	110	自然進氣	前置前驅	麥花臣	扭力樑	汽油	可變氣門正時CVTC	2025-09-16 01:08:48.741543
361	171	339	Tiida	2011	2019	MR18DE	1798	131	自然進氣	前置前驅	麥花臣	扭力樑	汽油	Xtronic CVT變速系統	2025-09-16 01:08:48.744795
362	172	340	Sentra	2013	2019	MRA8DE	1997	144	自然進氣	前置前驅	麥花臣	多連桿	汽油	Xtronic CVT，VVEL技術	2025-09-16 01:08:48.747703
363	173	341	Altima	2013	2018	MRA8DE	2495	182	自然進氣	前置前驅	麥花臣	多連桿	汽油	Xtronic CVT，VVEL，智能全輪驅動	2025-09-16 01:08:48.750762
364	174	342	X-Trail	2007	2013	MR20DE	1997	141	自然進氣	前置四驅	麥花臣	多連桿	汽油	ALL MODE 4x4-i 智能四輪驅動	2025-09-16 01:08:48.755096
365	174	343	X-Trail	2013	2021	MR20DD	2488	171	自然進氣	前置四驅	麥花臣	多連桿	汽油	ALL MODE 4x4-i，ProPILOT駕駛輔助	2025-09-16 01:08:48.758961
366	175	344	Juke	2010	2019	MR16DDT	1618	190	渦輪增壓	前置前驅/四驅	麥花臣	多連桿	汽油	Turbo增壓引擎，DSC動態穩定控制	2025-09-16 01:08:48.76203
367	176	345	Murano	2009	2014	VQ35DE	3498	265	自然進氣	前置四驅	麥花臣	多連桿	汽油	智能全輪驅動系統，VVEL	2025-09-16 01:08:48.76493
368	177	346	Kicks	2017	2025	HR16DE	1598	120	自然進氣	前置前驅	麥花臣	多連桿	汽油	Xtronic CVT，智能安全輔助系統	2025-09-16 01:08:48.768005
369	178	347	GT-R	2008	2022	VR38DETT	3799	\N	雙渦輪增壓	四輪驅動	雙叉臂	多連桿	汽油	VR38DETT雙渦輪增壓引擎，ATTESA E-TS四輪驅動，Brembo煞車系統，電子懸吊控制	2025-09-16 01:08:48.772137
370	179	348	350Z	2003	2009	VQ35DE	3498	280	自然進氣	後輪驅動	雙叉臂	多連桿	汽油	VQ35DE自然進氣V6引擎，Brembo制動系統（部分車型），多連桿懸吊	2025-09-16 01:08:48.775579
371	180	349	370Z	2009	2020	VQ37VHR	3696	328	自然進氣	後輪驅動	雙叉臂	多連桿	汽油	VQ37VHR高轉速自然進氣V6引擎，VVEL，Brembo制動系統，運動化懸吊	2025-09-16 01:08:48.778858
372	181	350	WRX STI	2006	2011	 EJ20	1994	300	渦輪增壓	四輪驅動	雙叉臂	雙叉臂	汽油	Symmetrical AWD	2025-09-16 01:08:48.782127
373	181	351	WRX STI	2011	2014	 EJ25	2457	305	渦輪增壓	四輪驅動	雙叉臂	雙叉臂	汽油	Symmetrical AWD	2025-09-16 01:08:48.784814
374	181	352	2.0i	2012	2016	 FB20	1995	156	自然進氣	四輪驅動	雙叉臂	雙叉臂	汽油	Symmetrical AWD，Lineartronic CVT	2025-09-16 01:08:48.78887
375	182	353	2.0XT	2008	2013	 EJ20	1994	237	渦輪增壓	四輪驅動	雙叉臂	雙叉臂	汽油	Symmetrical AWD，渦輪增壓水平對臥引擎	2025-09-16 01:08:48.792184
376	182	354	2.0i	2013	2018	 FB20	1995	150	自然進氣	四輪驅動	雙叉臂	雙叉臂	汽油	Symmetrical AWD，EyeSight駕駛輔助系統	2025-09-16 01:08:48.795208
377	182	355	2.0i-L	2018	2022	 FB20	1995	156	自然進氣	四輪驅動	雙叉臂	雙叉臂	汽油	Symmetrical AWD，EyeSight系統，X-MODE越野模式	2025-09-16 01:08:48.798008
378	183	356	2.0GT	2005	2009	 EJ20	1994	280	渦輪增壓	四輪驅動	雙叉臂	多連桿	汽油	Symmetrical AWD，渦輪增壓引擎	2025-09-16 01:08:48.800961
379	183	357	2.5i	2009	2014	 EJ25	2457	170	自然進氣	四輪驅動	雙叉臂	多連桿	汽油	Symmetrical AWD，EyeSight系統	2025-09-16 01:08:48.804767
380	184	358	WRX STI	2014	2021	 EJ25	2457	305	渦輪增壓	四輪驅動	雙叉臂	雙叉臂	汽油	Symmetrical AWD，Driver Controlled Center Differential	2025-09-16 01:08:48.807889
381	185	359	2.0L	2012	2020	 FA20	1998	200	自然進氣	後輪驅動	雙叉臂	雙叉臂	汽油	水平對臥引擎，輕量化車身，運動化懸吊	2025-09-16 01:08:48.811234
\.


--
-- Name: garage_query_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.garage_query_logs_id_seq', 1, false);


--
-- Name: garages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.garages_id_seq', 1, false);


--
-- Name: generations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.generations_id_seq', 359, true);


--
-- Name: makes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.makes_id_seq', 16, true);


--
-- Name: models_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.models_id_seq', 185, true);


--
-- Name: order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.order_items_id_seq', 1, false);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orders_id_seq', 1, false);


--
-- Name: part_compatibilities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.part_compatibilities_id_seq', 1, false);


--
-- Name: parts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.parts_id_seq', 1, false);


--
-- Name: price_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.price_rules_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: vehicle_variants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.vehicle_variants_id_seq', 381, true);


--
-- Name: garage_query_logs garage_query_logs_garage_id_query_type_reset_date_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.garage_query_logs
    ADD CONSTRAINT garage_query_logs_garage_id_query_type_reset_date_key UNIQUE (garage_id, query_type, reset_date);


--
-- Name: garage_query_logs garage_query_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.garage_query_logs
    ADD CONSTRAINT garage_query_logs_pkey PRIMARY KEY (id);


--
-- Name: garages garages_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.garages
    ADD CONSTRAINT garages_name_key UNIQUE (name);


--
-- Name: garages garages_phone_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.garages
    ADD CONSTRAINT garages_phone_key UNIQUE (phone);


--
-- Name: garages garages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.garages
    ADD CONSTRAINT garages_pkey PRIMARY KEY (id);


--
-- Name: garages garages_tax_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.garages
    ADD CONSTRAINT garages_tax_id_key UNIQUE (tax_id);


--
-- Name: generations generations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.generations
    ADD CONSTRAINT generations_pkey PRIMARY KEY (id);


--
-- Name: makes makes_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.makes
    ADD CONSTRAINT makes_name_key UNIQUE (name);


--
-- Name: makes makes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.makes
    ADD CONSTRAINT makes_pkey PRIMARY KEY (id);


--
-- Name: models models_make_id_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.models
    ADD CONSTRAINT models_make_id_name_key UNIQUE (make_id, name);


--
-- Name: models models_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.models
    ADD CONSTRAINT models_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: part_compatibilities part_compatibilities_part_id_vehicle_variant_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.part_compatibilities
    ADD CONSTRAINT part_compatibilities_part_id_vehicle_variant_id_key UNIQUE (part_id, vehicle_variant_id);


--
-- Name: part_compatibilities part_compatibilities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.part_compatibilities
    ADD CONSTRAINT part_compatibilities_pkey PRIMARY KEY (id);


--
-- Name: parts parts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts
    ADD CONSTRAINT parts_pkey PRIMARY KEY (id);


--
-- Name: parts parts_sku_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parts
    ADD CONSTRAINT parts_sku_key UNIQUE (sku);


--
-- Name: price_rules price_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.price_rules
    ADD CONSTRAINT price_rules_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: vehicle_variants vehicle_variants_model_id_engine_code_year_from_year_to_var_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vehicle_variants
    ADD CONSTRAINT vehicle_variants_model_id_engine_code_year_from_year_to_var_key UNIQUE (model_id, engine_code, year_from, year_to, variant_name);


--
-- Name: vehicle_variants vehicle_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vehicle_variants
    ADD CONSTRAINT vehicle_variants_pkey PRIMARY KEY (id);


--
-- Name: idx_part_compatibilities_part_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_part_compatibilities_part_id ON public.part_compatibilities USING btree (part_id);


--
-- Name: idx_part_compatibilities_vehicle_variant_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_part_compatibilities_vehicle_variant_id ON public.part_compatibilities USING btree (vehicle_variant_id);


--
-- Name: idx_parts_brand; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_parts_brand ON public.parts USING btree (brand);


--
-- Name: idx_parts_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_parts_category ON public.parts USING btree (category);


--
-- Name: idx_price_rules_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_price_rules_role ON public.price_rules USING btree (role);


--
-- Name: idx_price_rules_scope; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_price_rules_scope ON public.price_rules USING btree (scope_type, scope_value);


--
-- Name: idx_users_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_role ON public.users USING btree (role);


--
-- Name: idx_vehicle_variants_year; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_vehicle_variants_year ON public.vehicle_variants USING btree (year_from, year_to);


--
-- Name: parts update_parts_timestamp; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_parts_timestamp BEFORE UPDATE ON public.parts FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: garage_query_logs garage_query_logs_garage_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.garage_query_logs
    ADD CONSTRAINT garage_query_logs_garage_id_fkey FOREIGN KEY (garage_id) REFERENCES public.garages(id) ON DELETE CASCADE;


--
-- Name: garages garages_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.garages
    ADD CONSTRAINT garages_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: generations generations_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.generations
    ADD CONSTRAINT generations_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.models(id) ON DELETE CASCADE;


--
-- Name: models models_make_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.models
    ADD CONSTRAINT models_make_id_fkey FOREIGN KEY (make_id) REFERENCES public.makes(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: order_items order_items_part_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_part_id_fkey FOREIGN KEY (part_id) REFERENCES public.parts(id);


--
-- Name: orders orders_garage_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_garage_id_fkey FOREIGN KEY (garage_id) REFERENCES public.garages(id) ON DELETE CASCADE;


--
-- Name: part_compatibilities part_compatibilities_part_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.part_compatibilities
    ADD CONSTRAINT part_compatibilities_part_id_fkey FOREIGN KEY (part_id) REFERENCES public.parts(id) ON DELETE CASCADE;


--
-- Name: part_compatibilities part_compatibilities_vehicle_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.part_compatibilities
    ADD CONSTRAINT part_compatibilities_vehicle_variant_id_fkey FOREIGN KEY (vehicle_variant_id) REFERENCES public.vehicle_variants(id) ON DELETE CASCADE;


--
-- Name: vehicle_variants vehicle_variants_generation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vehicle_variants
    ADD CONSTRAINT vehicle_variants_generation_id_fkey FOREIGN KEY (generation_id) REFERENCES public.generations(id);


--
-- Name: vehicle_variants vehicle_variants_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vehicle_variants
    ADD CONSTRAINT vehicle_variants_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.models(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 6lOPnsraWNO5BTRoRtyw3FZaQuZMLsisOobRSVCy9sNHDYoyb4Ufky6RUPzLmH3

